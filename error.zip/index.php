<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:03

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661868)/* Founder*/;  
 
$link = ['hdev_c/executor/include','hdev_c/catch','hdev_c/head','hdev_c/menu','hdev_c/pre_menu','hdev_c/body','hdev_c/footer_all']; foreach ($link as $crfd2gChk) { include $crfd2gChk.'.php'; }  
; ?>
