<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661868)/* Founder*/;$tjnfvr1217='PGRpdiBjbGFzcz0iY29udGVudCI+CiAgICAgIDxkaXYgY2xhc3M9ImNvbnRhaW5lciI+CiAgICAgIA==';$yrplai1218='CiAgICAgIDxkaXYgY2xhc3M9InJvdyIgYWxpZ249ImNlbnRlciI+CiAgICAgICAgPGRpdiBjbGFzcz0iY29sLXNtLTEiPjwvZGl2PgogICAgICAgICAgPGRpdiBjbGFzcz0iY29sLXNtLTEwIj4KICAgICAgICAgICAgPGRpdiBjbGFzcz0iY2FyZCBjYXJkLXByaW1hcnkgY2FyZC1vdXRsaW5lIiBzdHlsZT0iaGVpZ2h0OiAxMDAlOyI+CiAgICAgICAgICAgICAgPGRpdiBjbGFzcz0iY2FyZC1oZWFkZXIiPjxoMz48aSBjbGFzcz0iZmFzIGZhLWV4Y2xhbWF0aW9uLXRyaWFuZ2xlIHRleHQtd2FybmluZyI+PC9pPiBPb3BzISBOZXR3b3JrIGZhaWx1cmUuPC9oMz4KICAgICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSJjYXJkLWJvZHkgdGFibGUtcmVzcG9uc2l2ZSBwLTMiPgogICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0icm93Ij4KICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0iY29sLXNtLTEiPgogICAgICAgICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0iY29sLXNtLTEwIj4KICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3M9ImhlYWRsaW5lIHRleHQtd2FybmluZyB0ZXh0LXhsIj4gNDA0PC9oMT4KICAgICAgICAgICAgICAgICAgICA8cCBjbGFzcz0iYm9yZGVyLXRvcCBib3JkZXItYm90dG9tIGJvcmRlci1sZWZ0IGJvcmRlci1yaWdodCBwLTMgdGV4dC13YXJuaW5nIj4KICAgICAgICAgICAgICAgICAgICAgIFdlIGNvdWxkIG5vdCBmaW5kIHRoZSBwYWdlIHlvdSB3ZXJlIGxvb2tpbmcgZm9yLjxicj4KICAgICAgICAgICAgICAgICAgICAgIFBMRUFTRSBUUlkgQUdBSU4gTEFURVI8YnI+PGJyPgogICAgICAgICAgICAgICAgICAgICAgTXdpaGFuZ2FuZSE8YnI+SWJ5byBtd2FzYWJ5ZSBudGliaWJhc2hpamUga3Vib25la2EgbXdvbmdlcmUgbXVnZXJhZ2V6ZSBtdWthbnlhITxicj4KICAgICAgICAgICAgICAgICAgICAgIEhhdnV0c2UgaWtpYmF6bywgdHVyaW1vIGt1Z2VyYWdlemEga3VnaWtlbXVyYTxicj4KICAgICAgICAgICAgICAgICAgICAgIA==';$maypyu1219='CiAgICAgICAgICAgICAgICAgICAgPC9wPgogICAgICAgICAgICAgICAgICA8L2Rpdj4gICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSJjYXJkLWZvb3RlciI+CiAgICAgICAgICAgICAgICA8aT4mY29weTsg';$flvfmt1220='ICAtIA==';$hkqrhy1221='PC9pPgogICAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDwvZGl2PgogICAgICAgICAgPCEtLSAvLmNvbCAtLT4KICAgICAgPC9kaXY+CiAgICAgIA==';$gtytuj1222='CiAgICAgIDxkaXYgY2xhc3M9InJvdyIgYWxpZ249ImNlbnRlciI+CiAgICAgICAgPGRpdiBjbGFzcz0iY29sLXNtLTMiPjwvZGl2PgogICAgICAgICAgPGRpdiBjbGFzcz0iY29sLXNtLTYiPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJjYXJkIGNhcmQtcHJpbWFyeSBjYXJkLW91dGxpbmUiIHN0eWxlPSJoZWlnaHQ6IDEwMCU7Ij4KICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSJjYXJkLWhlYWRlciI+PGgzIGNsYXNzPSJ0ZXh0LXByaW1hcnkiPjxpIGNsYXNzPSJmYXMgZmEtZXhjbGFtYXRpb24tdHJpYW5nbGUgdGV4dC1wcmltYXJ5Ij48L2k+IEFjY2VzcyBkZW5pZWQuPC9oMz4KICAgICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSJjYXJkLWJvZHkgdGFibGUtcmVzcG9uc2l2ZSBwLTMiPgogICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0icm93Ij4KICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0iY29sLXNtLTEiPgogICAgICAgICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0iY29sLXNtLTEwIj4KICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz0iZmEgZmEtbG9jayBmYS01eCB0ZXh0LWRhbmdlciI+PC9pPjxicj4KICAgICAgICAgICAgICAgICAgICA8cCBjbGFzcz0iYm9yZGVyLXRvcCBib3JkZXItYm90dG9tIGJvcmRlci1sZWZ0IGJvcmRlci1yaWdodCBwLTMgbXQtMyB0ZXh0LWRhbmdlciI+CiAgICAgICAgICAgICAgICAgICAgICA=';$igsqwf1223='CiAgICAgICAgICAgICAgICAgICAgPC9wPgogICAgICAgICAgICAgICAgICA8L2Rpdj4gICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSJjYXJkLWZvb3RlciI+CiAgICAgICAgICAgICAgICA8aT4mY29weTsg';$mhxdvu1224='IC0g';$weyojo1225='PC9pPgogICAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDwvZGl2PgogICAgICAgICAgPCEtLSAvLmNvbCAtLT4KICAgICAgPC9kaXY+CiAgICAgIA==';$ewtirn1226='CiAgICAgIDwhLS0gLy5lcnJvci1wYWdlIC0tPgogICAgPC9kaXY+CiAgPC9kaXY+';print(base64_decode($tjnfvr1217)); if (!isset($hcn12bgF8)) { ;print(base64_decode($yrplai1218)); echo "you can't access : <b class='text-info text-nowrap'>".Xhba9gFiO::lMU91ghri()."</b>"; print(base64_decode($maypyu1219)); echo date('Y');  echo APP_PROGRAMMER["name"] ;print(base64_decode($flvfmt1220)); echo APP_NAME; print(base64_decode($hkqrhy1221)); }else{ ;print(base64_decode($gtytuj1222)); echo $hcn12bgF8."<br>";  echo "you can't access : <b class='text-info text-nowrap'>".Xhba9gFiO::lMU91ghri()."</b>"; print(base64_decode($igsqwf1223)); echo date('Y');  echo APP_PROGRAMMER["name"] ;print(base64_decode($mhxdvu1224)); echo APP_NAME; print(base64_decode($weyojo1225)); } ;print(base64_decode($ewtirn1226)); ?>
