<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:03

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661817)/* Founder*/;$jnngsx1145='PCFET0NUWVBFIGh0bWw+CjxodG1sPgoKPGhlYWQ+CiAgPCEtLSBCYXNpYyBQYWdlIEluZm8gLS0+CiAgPG1ldGEgY2hhcnNldD0idXRmLTgiPgogIDxtZXRhIG5hbWU9InZpZXdwb3J0IiBjb250ZW50PSJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MSI+CiAgPG1ldGEgbmFtZT0idGhlbWUtY29sb3IiIGNvbnRlbnQ9InJnYigwLDEyMywyNTUpIi8+CiAgPHRpdGxlPg==';$vgcdyx1146='IHx8IEFVVEg8L3RpdGxlPgogIDxsaW5rIHJlbD0ibWFuaWZlc3QiIGhyZWY9Ig==';$alaqrv1147='Ij4KICA8c2NyaXB0PgogICAgICAvL2lmIGJyb3dzZXIgc3VwcG9ydCBzZXJ2aWNlIHdvcmtlcgogICAgICBpZignc2VydmljZVdvcmtlcicgaW4gbmF2aWdhdG9yKSB7CiAgICAgICAgbmF2aWdhdG9yLnNlcnZpY2VXb3JrZXIucmVnaXN0ZXIoJw==';$odgcji1148='Jyk7CiAgICAgIH07CiAgPC9zY3JpcHQ+CiAgPCEtLSBTaXRlIGZhdmljb24gLS0+CiAgPGxpbmsgcmVsPSJhcHBsZS10b3VjaC1pY29uIiBocmVmPSI=';$whoret1149='Ij4KICA8bGluayByZWw9Imljb24iIHR5cGU9ImltYWdlL3BuZyIgaHJlZj0i';$plpfmw1150='Ij4KCiAgPCEtLSBNb2JpbGUgU3BlY2lmaWMgTWV0YXMgLS0+CiAgPG1ldGEgbmFtZT0idmlld3BvcnQiIGNvbnRlbnQ9IndpZHRoPWRldmljZS13aWR0aCwgaW5pdGlhbC1zY2FsZT0xLCBtYXhpbXVtLXNjYWxlPTEiPgoKICA8IS0tIEdvb2dsZSBGb250IC0tPgogIDxsaW5rIGhyZWY9Imh0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzMj9mYW1pbHk9SW50ZXI6d2dodEAzMDA7NDAwOzUwMDs2MDA7NzAwOzgwMCZkaXNwbGF5PXN3YXAiIHJlbD0ic3R5bGVzaGVldCI+CiAgPCEtLSBDU1MgLS0+CiAgPGxpbmsgcmVsPSJzdHlsZXNoZWV0IiB0eXBlPSJ0ZXh0L2NzcyIgaHJlZj0i';$bfakgn1151='Ij4KICA8bGluayByZWw9InN0eWxlc2hlZXQiIHR5cGU9InRleHQvY3NzIiBocmVmPSI=';$vsonvb1152='Ij4KICA8bGluayByZWw9InN0eWxlc2hlZXQiIHR5cGU9InRleHQvY3NzIiBocmVmPSI=';$pkgegn1153='Ij4KICA8bGluayByZWw9InN0eWxlc2hlZXQiIHR5cGU9InRleHQvY3NzIiBocmVmPSI=';$qnxpyw1154='Ij4KICAgIDxsaW5rIHJlbD0ic3R5bGVzaGVldCIgaHJlZj0i';$isesqd1155='Ij4KCjwvaGVhZD4KPGJvZHkgY2xhc3M9ImxvZ2luLXBhZ2UiPg==';print(base64_decode($jnngsx1145)); echo APP_NAME; print(base64_decode($vgcdyx1146)); echo Xhba9gFiO::menu('manifest.json'); print(base64_decode($alaqrv1147)); echo Xhba9gFiO::menu('sw_ct.js'); print(base64_decode($odgcji1148)); echo Xhba9gFiO::menu('icon/on_small.png'); print(base64_decode($whoret1149)); echo Xhba9gFiO::menu('icon/og_image.png'); print(base64_decode($plpfmw1150)); echo Xhba9gFiO::menu('vendors/styles/core.css'); print(base64_decode($bfakgn1151)); echo Xhba9gFiO::menu('vendors/styles/icon-font.min.css'); print(base64_decode($vsonvb1152)); echo Xhba9gFiO::menu('src/plugins/jvectormap/jquery-jvectormap-2.0.3.css'); print(base64_decode($pkgegn1153)); echo Xhba9gFiO::menu('vendors/styles/style.css'); print(base64_decode($qnxpyw1154)); echo Xhba9gFiO::menu('src/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css');print(base64_decode($isesqd1155)); ?>
