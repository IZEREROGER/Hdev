<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:03

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661817)/* Founder*/;  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
   
 
 
class mtU11g8fs extends TCPDF {  
public function Header3() {  
$VMhbagZo1 = getcwd().DIRECTORY_SEPARATOR."icon".DIRECTORY_SEPARATOR.'rep_ico.jpg'; $this->Image($VMhbagZo1, 10, 10, 15, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);  
$this->SetFont('helvetica', 'B', 20);  
$this->Cell(0, 15, APP_NAME, 0, false, 'C', 0, '', 0, false, 'M', 'M'); $html = "<div><br><div>Sales Report<im src='".$VMhbagZo1."'></div> <hr>"; $this->writeHTML($html, true, false, true, false, ''); }  
public function Footer() {  
$this->SetY(-15);  
$this->SetFont('helvetica', 'I', 8);  
$this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages()." - Printed by :".dXfa0gHt3::Ack26gU3s("fid")." - ' ".dXfa0gHt3::Ack26gU3s("username")." '", 0, false, 'C', 0, '', 0, false, 'T', 'M'); } }  
$pdf = new mtU11g8fs(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);  
$pdf->SetCreator(PDF_CREATOR); $pdf->SetAuthor(APP_NAME); $pdf->SetTitle('Official Sales Report'); $pdf->SetSubject('Sales report'); $pdf->SetKeywords('Sales,report'); $group = dXfa0gHt3::groups(iKza4gt8P::sZr98ghPq(),['data']);  
 
$VMhbagZo1 = getcwd().DIRECTORY_SEPARATOR."icon".DIRECTORY_SEPARATOR.'rep_ico.jpg'; $pdf->SetHeaderData($VMhbagZo1, PDF_HEADER_LOGO_WIDTH, "(".$group['g_id'].") ".$group['g_name']." Stock"." \n", "Tel : ".$group['tell']." \n"."Email : ".$group['email']." \n"."Location : ".$group['g_location']." \non ".date('d/m/Y'));  
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN)); $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);  
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT); $pdf->SetHeaderMargin(PDF_MARGIN_HEADER); $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);  
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);  
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) { require_once(dirname(__FILE__).'/lang/eng.php'); $pdf->setLanguageArray($l); }  
 
$pdf->SetFont('times', '', 12);  
$pdf->AddPage('L', 'A4'); $from = MVoa8gCb_::get('start'); $to = MVoa8gCb_::get('end'); $oIP58gX9b = ''; if (!empty($to) && !empty($from)) { $oIP58gX9b .= "Viewing Sales Report from : "; $oIP58gX9b .= date_format(date_create($from),"d/m/Y"); $oIP58gX9b .= " - to : "; $oIP58gX9b .= date_format(date_create($to),"d/m/Y"); } $head='
    <h2 align="center">'.$oIP58gX9b.'</h2>
		<table style="width: 100%;border-collapse: collapse;" border="1px">
		    <thead>
          <tr style="padding: 10px;">
            <th><h4>Product #</h4></th>
            <th><h4>Product Name</h4></th>
            <th><h4>Sold Quantity</h4></th>
            <th><h4>Total buying Price</h4></th>
            <th><h4>Total Selling Price</h4></th>
            <th><h4>Profit/Loss</h4></th>
            <th><h4>Observation</h4></th>
          </tr>
		    </thead>
		    <tbody>
    '; $body = ""; $COV38gesi = dXfa0gHt3::report(); $sum = dXfa0gHt3::report('',['sum']); foreach ($COV38gesi AS $stock) { $nVg17cgbT = ($stock['income'] > 0) ? "Profit" : "Loss"; $body .= '
                    <tr>
                      <td>'.$stock["p_id"].'</td>
                      <td>'.$stock['p_name'].'</td>
                      <td>'.$stock['qty'].'</td>
                      <td>'.number_format($stock["buy_price"],2).constant('currency').'</td>
                      <td>'.number_format($stock['sell_price'],2).constant('currency').'</td>
                      <td>'.number_format($stock['income'],2).constant('currency').'</td>
                      <td>'.$nVg17cgbT.'</td>
                    </tr>
    	'; } $Bgf17egme = ($sum['income'] > 0) ? "Profit" : "Loss"; $JBz7agfEE = '
                    <tr>
                    	<th colspan="2">Total</th>
                      <td>'.$sum['qty'].'</td>
                      <td>'.number_format($sum["buy_price"],2).constant('currency').'</td>
                      <td>'.number_format($sum['sell_price'],2).constant('currency').'</td>
                      <td>'.number_format($sum['income'],2).constant('currency').'</td>
                      <td>'.$Bgf17egme.'</td>
                    </tr>
			    </tbody>
			</table>
	    ';  
$html = $head.$body.$JBz7agfEE;    
$pdf->writeHTML($html, true, false, true, false, '');  
 
$pdf->Output('Sales report.pdf', 'I');  
 
 
 ?>
