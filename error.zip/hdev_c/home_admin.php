<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:03

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661817)/* Founder*/;$iwpbmm1131='CiAgICAgICAgPGRpdiBjbGFzcz0icGFnZS1oZWFkZXIiPgogICAgICAgICAgPGRpdiBjbGFzcz0icm93Ij4KICAgICAgICAgICAgPGRpdiBjbGFzcz0iY29sLW1kLTEyIGNvbC1zbS0xMiIgYWxpZ249ImNlbnRlciI+CiAgICAgICAgICAgICAgPGRpdiBjbGFzcz0idGl0bGUiPgogICAgICAgICAgICAgICAgPGg0PldvcmtpbmcgQXMgOiA8c3BhbiBjbGFzcz0id2VpZ2h0LTYwMCBmb250LTMwIHRleHQtYmx1ZSI+U3VwZXIgQWRtaW48L3NwYW4+PC9oND4KICAgICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgPC9kaXY+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICA8L2Rpdj4KICAgIDxkaXYgY2xhc3M9InBkLWx0ci0yMCI+CiAgICAgIDxkaXYgY2xhc3M9ImNhcmQtYm94IHBkLTIwIGhlaWdodC0xMDAtcCBtYi0zMCI+CiAgICAgICAgPGRpdiBjbGFzcz0icm93IGFsaWduLWl0ZW1zLWNlbnRlciI+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJjb2wtbWQtNCI+CiAgICAgICAgICAgIDxpbWcgc3JjPSI=';$wtqxkf1132='IiBhbHQ9IiI+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDxkaXYgY2xhc3M9ImNvbC1tZC04Ij4KICAgICAgICAgICAgPGg0IGNsYXNzPSJmb250LTIwIHdlaWdodC01MDAgbWItMTAgdGV4dC1jYXBpdGFsaXplIj4KICAgICAgICAgICAgICBXZWxjb21lIHRvIDogPGRpdiBjbGFzcz0id2VpZ2h0LTYwMCBmb250LTMwIHRleHQtYmx1ZSI+';$apfgnu1133='PC9kaXY+CiAgICAgICAgICAgIDwvaDQ+CiAgICAgICAgICAgIDxwIGNsYXNzPSJmb250LTE4IG1heC13aWR0aC02MDAiPkEgcG93ZXJmdWxsIFN0b2NrIG1hbmFnZW1lbnQgc3lzdGVtPC9wPgogICAgICAgICAgPC9kaXY+CiAgICAgICAgPC9kaXY+CiAgICAgIDwvZGl2PgogICAgPC9kaXY+Cgo='; if (iKza4gt8P::oPHd8gEm1()): ;print(base64_decode($iwpbmm1131)); echo Xhba9gFiO::menu('icon/og_baner.png'); print(base64_decode($wtqxkf1132)); echo APP_NAME; print(base64_decode($apfgnu1133)); endif ; ?>
