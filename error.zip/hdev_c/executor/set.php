<?php  
	define("APP_NAME", "Xander Store system");
	define('APP_MASK', 'Xander Store system');
	define("district", "Kicukiro District");
	define('tel', '0788888888');
	define('currency', 'Frw');
	define('working_dev','dev');//prod in production // dev in development
	define('type', 'no');//secure in production // no in development

	define('APP_PREFIX', 'JNV-pay');
	define('SMS_SENDER', 'HDEV');
	define('SMS_USERNAME', 'izereroger1');
	define('SMS_PASSWORD', '...ROG..');
	define("APP_VERSION", "1.1");
	define('APP_PROGRAMMER', ['name'=>'Alexandre','email'=>'xander@gmail.com']);
	define('APP_SQLITE_DB',"janvier");


	/*define('dbhost',"localhost");
	define('db',"hdev_store");
	define('db_preview',"hdev_store");
	define('dbpass_preview', '');
	define('dbusr_preview', 'root');	
	define('dbpass', '');
	define('dbusr', 'root');
	define('dbport', '3306');
	define('dbport_preview', '3306');
	define('db_remote', 'st_soft');
	define('dbusr_remote', 'roger');	
	define('dbpass_remote', 'qwe');
	define('dbport_remote', '3309');*/

	define('dbhost',"fdb34.awardspace.net");
	define('db',"4044286_roger");
	define('db_preview',"4044286_roger");
	define('dbpass_preview', 'Hrwroger1@gmail.com');
	define('dbusr_preview', '4044286_roger');	
	define('dbpass', 'Hrwroger1@gmail.com');
	define('dbusr', '4044286_roger');
	define('dbport', '3306');
	define('dbport_preview', '3306');
	define('db_remote', 'st_soft');
	define('dbusr_remote', 'roger');	
	define('dbpass_remote', 'qwe');
	define('dbport_remote', '3309');
	//error_reporting(0);
 ?>