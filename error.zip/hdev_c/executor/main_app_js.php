<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:03

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/;$uqtdcn945='CmZ1bmN0aW9uIGR5bmFtaWNhbGx5TG9hZFNjcmlwdCh1cmwpIHsKICAgIHZhciBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCJzY3JpcHQiKTsKICAgIHNjcmlwdC5zcmMgPSB1cmw7CiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHNjcmlwdCk7Cn0K';  
$script = array( "plugins/bootstrap/js/bootstrap.bundle.js", "plugins/pace-progress/pace.js", "plugins/overlayScrollbars/js/jquery.overlayScrollbars.js", "dist/js/adminlte.js",   "plugins/datatables/jquery.dataTables.js", "plugins/datatables-bs4/js/dataTables.bootstrap4.js", "plugins/datatables-responsive/js/dataTables.responsive.js", "plugins/datatables-responsive/js/responsive.bootstrap4.js", "plugins/datatables-buttons/js/dataTables.buttons.js", "plugins/datatables-buttons/js/buttons.bootstrap4.js", "plugins/datatables-fixedcolumns/js/dataTables.fixedColumns.js", "plugins/jszip/jszip.js", "plugins/pdfmake/pdfmake.js", "plugins/pdfmake/vfs_fonts.js", "plugins/datatables-buttons/js/buttons.html5.js", "plugins/datatables-buttons/js/buttons.print.js", "plugins/datatables-buttons/js/buttons.colVis.js", "plugins/bs-stepper/js/bs-stepper.js", "plugins/ajax/sl.js", "plugins/ajax/former.js", );   class OiRa2gAaX { public static function oIP58gX9b($script=array()) { $PMC128gTS = getcwd().DIRECTORY_SEPARATOR; foreach ($script as $js) { $tArc8gPm6 = Xhba9gFiO::menu($js); echo "dynamicallyLoadScript('".$tArc8gPm6."');"; } } } ;print(base64_decode($uqtdcn945)); OiRa2gAaX::oIP58gX9b($script);  ?>
