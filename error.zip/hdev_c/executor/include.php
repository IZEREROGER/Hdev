<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:03

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/; session_start(); $LNe50gZ9q = getcwd().DIRECTORY_SEPARATOR."hdev_c".DIRECTORY_SEPARATOR."executor".DIRECTORY_SEPARATOR."control".DIRECTORY_SEPARATOR; $l = ['set','url_service','service']; foreach ($l as $crfd2gChk) { $aHC13dgLD = __DIR__; $YUM13agBN = str_ireplace('\\', "/", $aHC13dgLD); include $YUM13agBN.'/'.$crfd2gChk.'.php'; } $bDpcagAUg = ['session_url','search','auth','log','menu','url','route_body','notification','lang','csrf_protect','db_init','db_pager','backup']; foreach ($bDpcagAUg as $link) { include $LNe50gZ9q.$link.".php"; } $aHC13dgLD = __DIR__; $YUM13agBN = str_ireplace('\\', "/", $aHC13dgLD); include $YUM13agBN.'/'.'real_executor'.'.php'; $aHC13dgLD = __DIR__; $YUM13agBN = str_ireplace('\\', "/", $aHC13dgLD); include $YUM13agBN.'/'.'exp'.'.php';  ?>
