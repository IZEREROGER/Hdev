<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/;   class CSRF_Protect {   private $namespace;   public function __construct($namespace = 'tkd') { $this->namespace = $namespace; if (session_id() === '') { session_start(); } $this->jYZ170gTZ(); }   public function DbF83gRna() { return $this->zIY131gRB(); }   public function sXHbfg0oq($Fpb1a4gg3) { return ($Fpb1a4gg3 === $this->zIY131gRB()); }   public function VSn5fgzgV() { $token = $this->DbF83gRna(); echo "<input type=\"hidden\" name=\"{$this->namespace}\" value=\"{$token}\" />"; }   public function faT1aagoV($var="") { if ($var == "") { if (!isset($_POST[$this->namespace])) { die("Data validation failed."); } if (!$this->sXHbfg0oq($_POST[$this->namespace])) { die("Data validation failed."); } }else{ if (!$this->sXHbfg0oq($var)) { die("Data validation failed."); } } }   private function jYZ170gTZ() { $mzX17agN8 = $this->zIY131gRB(); if ($mzX17agN8 === '') { $token = md5(uniqid(rand(), TRUE)); $this->hMN1b0gUJ($token); } } public function hsc199g72() { $token = md5(uniqid(rand(), TRUE)); $this->hMN1b0gUJ($token); }  
private function zIY131gRB() { if (isset($_SESSION[$this->namespace])) { return $_SESSION[$this->namespace]; } else { return ''; } }   private function hMN1b0gUJ($token) { $_SESSION[$this->namespace] = $token; } } ; ?>
