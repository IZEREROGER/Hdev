<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/;   class afSadgZf6 { public static function DpPaegBtV($eGj17bgrV) { return str_ireplace(array("'",'"'), array('\'',"\""), $eGj17bgrV); }
public static function message($dIeecgGr5) { echo '
          <script>alert(\''.$dIeecgGr5.'\')</script>
         '; } public static function nd_nav($min) { $Sce1a2gbl = trim($_SESSION['nd_url'][1]); if ($min == $Sce1a2gbl) { echo " btn-primary"; }else{ echo " btn-secondary"; } } public static function topmenu($trees,$name,$link,$icon,$id='',$power='') { if (empty($_SESSION["act_url"])) {  
}else{ if (empty($_SESSION["act_url"][2])) {  
}else{ $Sce1a2gbl = trim(Xhba9gFiO::knk92gS24().$_SESSION['act_url'][2]); } } if (empty($name)) { echo ""; }elseif ($trees == "1") { $ziH7fgEX6 = ' btn_destination="'."hdev_url__".md5(dXfa0gHt3::Dnc64gTRt($link."_".$biP158gHZ)).'" '; $id = (!empty($id)) ? ' id=\''.$id.'\'' : '' ; $power = (!empty($power)) ? $power : '' ; $view = '<li class="nav-item text-nowrap">'; $error = ""; if (!empty($link)) { $VCed1gdPi = explode("...", $link); if (is_array($VCed1gdPi) && count($VCed1gdPi) == 2) { $NFE1a3gqE = Xhba9gFiO::knk92gS24().'/'.trim($VCed1gdPi[0]).'/'.trim($VCed1gdPi[1]); }elseif (is_array($VCed1gdPi) && count($VCed1gdPi) == 1) { $NFE1a3gqE = Xhba9gFiO::knk92gS24().'/'.trim($VCed1gdPi[0]); }else{ $NFE1a3gqE = Xhba9gFiO::knk92gS24(); }  
BnHa7g834::access('/', false, false, false, $NFE1a3gqE); $eZo12egjZ = new VAXaagA2I('',trim(BnHa7g834::YsJ86gY1r())); if ($eZo12egjZ->access()) { if ($Sce1a2gbl == $NFE1a3gqE) { $XHX116gXl = ""; if (constant("APP_MASK") != "") { $XHX116gXl = " -- " .constant("APP_MASK"); } $view .='<a  href="'.$NFE1a3gqE.'" class="lift nav-link active'.$power.'"'.$ziH7fgEX6.$id.' title="'.'RASMS'.'---' .self::DpPaegBtV($name).$XHX116gXl.'"">'; }else{ $XHX116gXl = ""; if (constant("APP_MASK") != "") { $XHX116gXl = " -- " .constant("APP_MASK"); } $view .='<a  href="'.$NFE1a3gqE.'" class="text-nowrap lift nav-link'.$power.'"'.$ziH7fgEX6.$id.' title="'.'RASMS'.'---' .self::DpPaegBtV($name).$XHX116gXl.'"">'; } }else{ $error ="no"; } }else{ $error = "no"; } if ($error == "") { if (!empty($icon)) { $view .= '<i class="nav-icon '.trim($icon).'"></i>'; if (!empty($link)) { $view .="&nbsp;".self::DpPaegBtV($name).'</a>'; } $view .= "</li>"; echo $view; } } } } public static function DcDdagDqo($trees,$name,$link,$icon,$power='') { $Sce1a2gbl = trim(Xhba9gFiO::knk92gS24().$_SESSION['act_url'][2]); if (empty($name)) { }elseif ($trees == "1") { $ziH7fgEX6 =' btn_destination="'."hdev_url__".md5(dXfa0gHt3::Dnc64gTRt($link."_".rand())).'" '; $RCE1acgho = '<li>'; $view = ""; $power = (!empty($power)) ? $power : '' ; $error = ""; if (!empty($link)) { $VCed1gdPi = explode("...", $link); if (is_array($VCed1gdPi) && count($VCed1gdPi) == 2) { $NFE1a3gqE = Xhba9gFiO::knk92gS24().'/'.trim($VCed1gdPi[0]).'/'.trim($VCed1gdPi[1]); }elseif (is_array($VCed1gdPi) && count($VCed1gdPi) == 1) { $NFE1a3gqE = Xhba9gFiO::knk92gS24().'/'.trim($VCed1gdPi[0]); }else{ $NFE1a3gqE = Xhba9gFiO::knk92gS24(); } BnHa7g834::access('/', false, false, false, $NFE1a3gqE); $eZo12egjZ = new VAXaagA2I('',trim(BnHa7g834::YsJ86gY1r())); if ($eZo12egjZ->access()) { if ($Sce1a2gbl == $NFE1a3gqE) { $XHX116gXl = ""; if (constant("APP_MASK") != "") { $XHX116gXl = " -- " .constant("APP_MASK"); } $view .='<a href="'.$NFE1a3gqE.'" class="dropdown-toggle no-arrow active '.$power.'"'.$ziH7fgEX6.'title="'.APP_NAME.' - ' .self::DpPaegBtV($name).$XHX116gXl.'">'; }else{ $XHX116gXl = ""; if (constant("APP_MASK") != "") { $XHX116gXl = " -- " .constant("APP_MASK"); } $view .='<a href="'.$NFE1a3gqE.'" class="dropdown-toggle no-arrow '.$power.'"'.$ziH7fgEX6.'title="'.APP_NAME.' - ' .self::DpPaegBtV($name).$XHX116gXl.'">'; } }else{ $error = "no"; } }else{ $error = "no"; } if ($error == "") { if (!empty($icon)) { $view .= '<span class="nav-icon micon '.trim($icon).'"></span><span class="mtext">'; } if (!empty($link)) { $view .=self::DpPaegBtV(trim($name)).'</span></a>'; } $view .= "</li>"; echo $RCE1acgho.$view; } }elseif ($trees == "2") { $biP158gHZ = rand(); $ziH7fgEX6 = ' btn_destination="'."hdev_url__".md5(dXfa0gHt3::Dnc64gTRt($link."_".$biP158gHZ)).'" '; $ZbK80gPGm = ' btn_destination_parent_1="'."hdev_url__".md5(dXfa0gHt3::Dnc64gTRt($link."_".$biP158gHZ)).'" '; $IEZ81g5PH = ' btn_destination_parent_2="'."hdev_url__".md5(dXfa0gHt3::Dnc64gTRt($link."_".$biP158gHZ)).'" '; $view=""; $name = explode("^^", $name); $link = explode("^^", $link); $icon = explode("^^", $icon); $power = (!empty($power)) ? explode("^^", $power) : "" ;
if (count($name)==count($link) && count($name)==count($icon) ) { $KBH19ag9m =array(); $mRg17fgSi = array(); for ($i=1; $i <= count($name)-1; $i++) { $k = $i; $VCed1gdPi = explode("...", $link[$i]); if (!empty($link)) { if (count($VCed1gdPi) == 2) { $NFE1a3gqE = Xhba9gFiO::knk92gS24().'/'.trim($VCed1gdPi[0]).'/'.trim($VCed1gdPi[1]); BnHa7g834::access('/', false, false, false, $NFE1a3gqE); $eZo12egjZ = new VAXaagA2I('',trim(BnHa7g834::YsJ86gY1r())); if ($eZo12egjZ->access()) { array_push($mRg17fgSi, "y"); if ($Sce1a2gbl == $NFE1a3gqE) { array_push($KBH19ag9m, "y"); } } } } } if (in_array("y", $mRg17fgSi)) { if (in_array("y", $KBH19ag9m)) { $view = '<li class="dropdown show"'.$ZbK80gPGm.'>
                        <a href="javascript:;" class="dropdown-toggle" data-option="on"'.$IEZ81g5PH.'>'; $sub_menu = "display: block;"; }else{ $view = '<li class="dropdown"'.$ZbK80gPGm.'>
                         <a href="javascript:;" class="dropdown-toggle"'.$IEZ81g5PH.'>'; $sub_menu = ""; } $view .='
                <span class="micon '; $view .= trim($icon[0]); $view .='"></span>
                <span class="mtext">'; $view.=self::DpPaegBtV(trim($name[0])); $view.='
                </span>
              </a>
              <ul class="submenu" style="{$sub_menu}">'; for ($i=1; $i <= count($name)-1; $i++) { $VCed1gdPi = explode("...", $link[$i]); $rKAefgXn3 = $name[$i]; $UXF110gXU = (isset($power[$i]) && !empty($power[$i])) ? ' rel="'.trim($power[$i]).'" ' : "" ; $error = ""; if (is_array($VCed1gdPi) && count($VCed1gdPi) == 2) { $NFE1a3gqE = Xhba9gFiO::knk92gS24().'/'.trim($VCed1gdPi[0]).'/'.trim($VCed1gdPi[1]); }elseif (is_array($VCed1gdPi) && count($VCed1gdPi) == 1) { $NFE1a3gqE = Xhba9gFiO::knk92gS24().'/'.trim($VCed1gdPi[0]); }else{ $NFE1a3gqE = Xhba9gFiO::knk92gS24(); } BnHa7g834::access('/', false, false, false, $NFE1a3gqE);  
$eZo12egjZ = new VAXaagA2I('',trim(BnHa7g834::YsJ86gY1r())); if ($eZo12egjZ->access()) { $view.='<li>'; if ($Sce1a2gbl == $NFE1a3gqE) { $XHX116gXl = ""; if (constant("APP_MASK") != "") { $XHX116gXl = " -- " .constant("APP_MASK"); } $view .='<a href="'.$NFE1a3gqE.'" class="active"'.$UXF110gXU.$ziH7fgEX6.'title="'.APP_NAME.' - ' .self::DpPaegBtV(trim($name[$i])).$XHX116gXl.'">'; }else{ $XHX116gXl = ""; if (constant("APP_MASK") != "") { $XHX116gXl = " -- " .constant("APP_MASK"); } $view .='<a href="'.$NFE1a3gqE.'" class=""'.$UXF110gXU.$ziH7fgEX6.'title="'.APP_NAME.' - ' .self::DpPaegBtV(trim($name[$i])).$XHX116gXl.'">';  
 
} }else{ $error = "no"; } if ($error == "") { $view.='<i class=" '.trim($icon[$i]).' nav-icon"></i>'; $view.=''.self::DpPaegBtV(trim($name[$i])).''; $view.='</a></li>'; } } $view.='
                    </ul>
                  </li>'; } } echo $view; } } } ; ?>
