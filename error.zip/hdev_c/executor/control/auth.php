<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/;   class lEIabgVDO { public static function login($user,$password) { $ZOV15fgYm = dXfa0gHt3::Aahd7g2SB($user,$password); if ($ZOV15fgYm != "no") { echo "ok"; }else{ echo ""; } } }   class cGL9eg5UH { function __construct($user='',$service) { global $Bhl12cgcz; global $tqq12dgBk; $this->user = (isset($user) && !empty($user) && $user != "") ? trim($user) : iKza4gt8P::uid(); $mPF1a5gBB = iKza4gt8P::fid();  
$this->service = trim($service); $this->user_group = (isset($mPF1a5gBB) && !isset($_GET['printer'])) ? trim($mPF1a5gBB) : "guest" ; $this->service_db = $Bhl12cgcz; $this->user_db = $tqq12dgBk; } public function access() { $DBG151g9V = false; if (isset($this->user_db[$this->user_group]) && is_array($this->user_db[$this->user_group])) {  
if (in_array($this->service, $this->user_db[$this->user_group])) { if (array_key_exists($this->service, $this->service_db) && isset($this->service_db[$this->service]['name'])) { $DBG151g9V = $this->service_db[$this->service]['name']; } } } return $DBG151g9V; } public function error($ref="") { $DBG151g9V = false; if (array_key_exists($this->service, $this->service_db) && isset($this->service_db[$this->service]['error'])) { $DBG151g9V = $this->service_db[$this->service]['error']; }else{ if ($ref == "") { return "Access Denied to you !!"; }elseif ($ref == "alert") { return ucfirst($DBG151g9V); }else{ exit("Access Denied to you !!"); } } if ($ref == "") { return ucfirst($DBG151g9V); }elseif ($ref == "alert") { return ucfirst($DBG151g9V); }else{ exit(ucfirst($DBG151g9V)); } } } class VAXaagA2I { function __construct($user='',$service) { global $eaC12fgZl; global $kZr130g_F; $this->user = (isset($user) && !empty($user) && $user != "") ? trim($user) : iKza4gt8P::uid(); $mPF1a5gBB = iKza4gt8P::fid();  
$this->service = trim($service); $this->user_group = (isset($mPF1a5gBB) && !empty($mPF1a5gBB) && !isset($_GET['printer'])) ? trim($mPF1a5gBB) : "guest" ; $this->service_db = $eaC12fgZl; $this->user_db = $kZr130g_F; } public function access() { $DBG151g9V = false;  
 
if (isset($this->user_db[$this->user_group]) && is_array($this->user_db[$this->user_group])) {  
if (in_array($this->service, $this->user_db[$this->user_group])) { if (array_key_exists($this->service, $this->service_db) && isset($this->service_db[$this->service]['name'])) { $DBG151g9V = $this->service_db[$this->service]['name']; } } } return $DBG151g9V; } public function error($ref="") { $DBG151g9V = false; echo $this->service;   if (array_key_exists($this->service, $this->service_db) && isset($this->service_db[$this->service]['error'])) { $DBG151g9V = $this->service_db[$this->service]['error']; }else{ if ($ref == "") { return "Access Denied to you !!!"; }elseif ($ref == "alert") { return ucfirst($DBG151g9V); }else{ exit("Access Denied to you !!"); } } if ($ref == "") { return ucfirst($DBG151g9V); }elseif ($ref == "alert") { return ucfirst($DBG151g9V); }else{ exit(ucfirst($DBG151g9V)); } } } ; ?>
