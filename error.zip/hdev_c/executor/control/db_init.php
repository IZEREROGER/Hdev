<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/;   class hNSa1g9lj { public $LKk3fgOpP = ""; function table($geg114gnK) { $table = array( "groups" => "h_groups", "main_auths" => "auth_storage", "all_users" => "auth_engine", "location"=>"locations", "products"=>"products", "stock_in"=>"stock_in", "stock_out"=>"stock_out", "cart"=>"stock_out_cart", "stock_detail"=>"stock_detail_transactions", "transaction"=>"transaction", "debit" => "debits", "debit_payment" => "debits_payment", "cash_received" => "cash_received", "cash_paid" => "cash_paid", "cash_trans" => "cash_trans", "cash_deposit" => "cash_deposit", "momo"=>"momo" ); return $table[$geg114gnK]; } function Rlg29gK4B($geg114gnK="") { $geg114gnK = (!empty($geg114gnK) && $geg114gnK != "") ? $geg114gnK : iKza4gt8P::fid(); $table = array( "admin"=>self::table("main_auths"), "super_admin"=>self::table("main_auths"), "main_stock"=>self::table("main_auths"), ); return $table[$geg114gnK]; } function auth_col($geg114gnK="") { $geg114gnK = (!empty($geg114gnK) && $geg114gnK != "") ? $geg114gnK : iKza4gt8P::fid(); $table = array( "admin"=>"a_id", "super_admin"=>"a_id", "agent"=>"a_id", ); return $table[$geg114gnK]; } function __construct($eDa42ghLl='pdo') { if ($eDa42ghLl == "pdo") { $kSs16cgLO = dbhost; $username = dbusr; $password = dbpass; $dbname = db; $port = dbport; try{ $this->LKk3fgOpP = new PDO("mysql:host=$kSs16cgLO;dbname=$dbname; charset=utf8;port=$port", $username, $password); } catch(PDOException $GYM68gLJ7){ $this->LKk3fgOpP = "error"; } }elseif ($eDa42ghLl == "sqlite") { echo getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'executor'.DIRECTORY_SEPARATOR.'control'.DIRECTORY_SEPARATOR.APP_SQLITE_DB; echo "<br>"; exit(__DIR__); $this->pdo = new PDO("sqlite:manage.db"); } } public function URD41gkDq() { $nob3agmdG = $this->LKk3fgOpP; if ($nob3agmdG == "error") { return false; }else{ return true; } } public function efGcegGik() { $XTh3egrXc = $this->LKk3fgOpP; $efGcegGik = $XTh3egrXc->lastInsertId();
return $efGcegGik; } public static function create_db($db='') { $DBG151g9V = false; if (!empty($db)) { $kSs16cgLO = dbhost; $username = dbusr; $password = dbpass; $port = dbport; $LKk3fgOpP = new PDO("mysql:host=$kSs16cgLO; charset=utf8;port=$port", $username, $password); $LKk3fgOpP->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $sql = "CREATE DATABASE IF NOT EXISTS ".$db; $dms164ghX = explode(";", $sql); $query = ""; if (isset($dms164ghX[0])) { $OMf124gCG = explode(" ", $sql); if (isset($OMf124gCG[0]) && $OMf124gCG[0] == "CREATE" && isset($OMf124gCG[1]) && $OMf124gCG[1] == "DATABASE" ) { $query = $dms164ghX['0']; } }  
 
if ($LKk3fgOpP->exec($query)) { $DBG151g9V = true; } } return $DBG151g9V; } function SZP40gkZJ() { $LKk3fgOpP = $this->LKk3fgOpP; if(is_null($LKk3fgOpP) || $LKk3fgOpP===FALSE) { die('Rasms Internal error'); } return $this->LKk3fgOpP; } function select($query = "SELECT 1=1",$RhN103gLt = null) {  
try { if (is_string($this->LKk3fgOpP)) { echo "<div style='width: 50%;margin-left:15%;margin-top:5%;'><fieldset>DATA STORE CHECKER<hr>Re-start the application to get this fixed <br> Or click <a href='".Xhba9gFiO::menu("")."'>Here</a><hr>&copy".date("Y")."- ".APP_PROGRAMMER['name']." - ".APP_NAME."<hr></fieldset><div>"; echo '<meta content="2; '.Xhba9gFiO::menu("").'" http-equiv="refresh" />'; exit(); } $this->LKk3fgOpP->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $bfM177g51 = $this->LKk3fgOpP->prepare($query); if (is_array($RhN103gLt) && count($RhN103gLt) > 0) { foreach ($RhN103gLt as $Zrh10bgkE) { if (!empty($Zrh10bgkE)) { $hSB13egVb = $Zrh10bgkE; if (is_array($hSB13egVb) && count($hSB13egVb)==2) { $bfM177g51->bindParam($hSB13egVb[0], $hSB13egVb[1]); } } } } $bfM177g51->execute(); $bfM177g51->setFetchMode(PDO::FETCH_ASSOC); $Eic147gJO = $bfM177g51->fetchAll(); } catch(PDOException $e) { $Eic147gJO = array(); if (constant('working_dev') == 'dev') { $Eic147gJO = array("Error: ",$e->getMessage()); } } return $Eic147gJO; $LKk3fgOpP = null; } function insert($query,$RhN103gLt= null) { try { if (is_string($this->LKk3fgOpP)) { echo "<div style='width: 50%;margin-left:15%;margin-top:5%;'><fieldset>DATA STORE CHECKER<hr>Re-start the application to get this fixed <br> Or click <a href='".Xhba9gFiO::menu("")."'>Here</a><hr>&copy".date("Y")."- ".APP_PROGRAMMER['name']." - ".APP_NAME."<hr></fieldset><div>"; echo '<meta content="2; '.Xhba9gFiO::menu("").'" http-equiv="refresh" />'; exit(); } $this->LKk3fgOpP->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $bfM177g51 = $this->LKk3fgOpP->prepare($query); if (is_array($RhN103gLt) && count($RhN103gLt) > 0) { foreach ($RhN103gLt as $Zrh10bgkE) { if (!empty($Zrh10bgkE)) { $hSB13egVb = $Zrh10bgkE; if (is_array($hSB13egVb) && count($hSB13egVb)==2) { $bfM177g51->bindParam($hSB13egVb[0], $hSB13egVb[1]); } } } } $bfM177g51->execute(); $TJz14fgXR = "ok"; } catch(PDOException $e) { if (constant('working_dev') == 'dev') { echo "error".$e->getMessage(); } $TJz14fgXR = "no"; } return $TJz14fgXR; $LKk3fgOpP = null; } function exec($query="") { $this->LKk3fgOpP->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $this->LKk3fgOpP->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC); $PFL14cgR4 = "no"; if ($this->LKk3fgOpP->exec($query)) { $PFL14cgR4 = "ok"; } return $PFL14cgR4; } } ; ?>
