<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/;   class MVoa8gCb_ { private static $nOP16egfk = array(); public static function eLC10agoR() { $VBC16fglB = array('publicKey','secretKey','env','successurl','failureurl','currency','amount'); foreach ($VBC16fglB as $Dbi16dgge) { if (isset($_SESSION[$Dbi16dgge])) { unset($_SESSION[$Dbi16dgge]); } } } public static function reset() { self::$nOP16egfk = array(); } public static function set($name='',$value='') { if (!empty($name)) { self::$nOP16egfk[$name] = $value; } } public static function get($name) { if (count(self::$nOP16egfk) > 0 && isset(self::$nOP16egfk[$name]) && !is_null(self::$nOP16egfk[$name])) { return self::$nOP16egfk[$name]; }else{ return ""; } } } ; ?>
