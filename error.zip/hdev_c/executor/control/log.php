<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/;   class iKza4gt8P { public static function wait($time="") { $VgG195gZl = 10; if (is_numeric($time) && $time > 0) { $VgG195gZl = $time; } sleep($VgG195gZl); } public static function out() { session_unset(); session_destroy(); if (isset($_GET['nxt']) && !empty($_GET["nxt"])) { kAGa6ghaY::XgH132g45(Xhba9gFiO::AKM25gA6G($_GET["nxt"])); }else{  
kAGa6ghaY::XgH132g45(Xhba9gFiO::menu("")); } } public static function currency() { return constant('currency'); } public static function uid() { if (isset($_SESSION['msg_id_id']) && !empty($_SESSION['msg_id_id'])) { return $_SESSION['msg_id_id']; }else{ return ''; } } public static function me() { $a = self::uid(); $b = "num_ip"; return $a.$b; } public static function sZr98ghPq() { if (isset($_SESSION['g_id']) && !empty($_SESSION['g_id'])) { return $_SESSION['g_id']; }else{ return ''; } } public static function sgid() { if (isset($_SESSION['sg_id']) && !empty($_SESSION['sg_id'])) { return $_SESSION['sg_id']; }else{ return ''; } } public static function fid() { if (isset($_SESSION['ffunct']) && !empty($_SESSION['ffunct'])) { return $_SESSION['ffunct']; }else{ return 'guest'; } } public static function admin() { $user = self::fid(); if ($user == "admin") { return true; }else{ return false; } } public static function oPHd8gEm1() { if (!empty($_SESSION['msg_id_id'])) { return true; }else{ return false; } } public static function main_stock() { if (isset($_SESSION['main_stock']) && !empty($_SESSION['main_stock'])) { return $_SESSION['main_stock']; }else{ return ""; } } public static function close() { if (self::oPHd8gEm1()) { exit(); } } public static function qr_folder() { $aHC13dgLD = __DIR__; $reM13cgrA = $aHC13dgLD; return realpath($reM13cgrA)."\qr_3"; } public static function qr_url_term($value='') { $sEq1aegd4 = urlencode(dXfa0gHt3::Dnc64gTRt($value)); return Xhba9gFiO::menu("auth/gen".'/'.$sEq1aegd4); } } ; ?>
