<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/;   class sBpa3gfRp { private static $lang = array(); public static function reset() { self::$lang = array(); } public function set($var=array()) { self::$lang = $var; } public static function ocO8cg_XF() { $sAjccgBXf = (isset($_SESSION['lang']) && !empty($_SESSION['lang'])) ? $_SESSION['lang'] : "eng" ; return $sAjccgBXf; } public static function on($bMs113gO3,$view) { $sAjccgBXf = (isset($_SESSION['lang']) && !empty($_SESSION['lang'])) ? $_SESSION['lang'] : "eng" ; if (!empty($bMs113gO3) && !empty($view)) { if (isset(self::$lang[$bMs113gO3][$sAjccgBXf][$view])) { if (!empty(self::$lang[$bMs113gO3][$sAjccgBXf][$view])) { return self::$lang[$bMs113gO3][$sAjccgBXf][$view]; }else{
return ""; } }else{ $sAjccgBXf = "eng"; if (isset(self::$lang[$bMs113gO3][$sAjccgBXf][$view]) && !empty(self::$lang[$bMs113gO3][$sAjccgBXf][$view])) { return self::$lang[$bMs113gO3][$sAjccgBXf][$view]; }else{ return ""; } } }else{ return ""; } } } ; ?>
