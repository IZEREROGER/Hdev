<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/;  
 
 
define("BASEPATH", 1); $PMC128gTS = getcwd().DIRECTORY_SEPARATOR."hdev_c".DIRECTORY_SEPARATOR."executor".DIRECTORY_SEPARATOR."control".DIRECTORY_SEPARATOR."hdev_softwares".DIRECTORY_SEPARATOR."library".DIRECTORY_SEPARATOR;  
include($PMC128gTS.'rave.php'); include($PMC128gTS.'raveEventHandlerInterface.php'); use Flutterwave\Rave; use Flutterwave\EventHandlerInterface; $URL = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; $CYjf9g5KD = MVoa8gCb_::get("tx_dta"); $fsB111gtJ=array( 'amount'=>$CYjf9g5KD['p_price'], "payment_options"=>"paypal,mobile_money_rwanda", "description"=>"HOUSE RENT", "logo"=>"https://hirwabms.000webhostapp.com/dist/img/rasms.ico", "title"=>APP_NAME." Payment", "country"=>"RW", "currency"=>"RWF", "email"=>$CYjf9g5KD['t_email'], "firstname"=>$CYjf9g5KD['t_name'], "lastname"=>"", "phonenumber"=>"+25".$CYjf9g5KD['t_tel'], "pay_button_text"=>"Ishyura inzu", "ref"=>$CYjf9g5KD['tx_ref'], "successurl"=>Xhba9gFiO::menu(""), 
"failureurl"=>Xhba9gFiO::menu("") 
); $ptM82gnXZ = $_GET; $publicKey = $_SERVER['PUBLIC_KEY']; $secretKey = $_SERVER['SECRET_KEY']; if(isset($_POST) && isset($fsB111gtJ['successurl']) && isset($fsB111gtJ['failureurl'])){ $SXi17dgU6 = $fsB111gtJ['successurl']; $oAl6egBoZ = $fsB111gtJ['failureurl']; } $env = $_SERVER['ENV']; if(isset($fsB111gtJ['amount'])){ $_SESSION['publicKey'] = $publicKey; $_SESSION['secretKey'] = $secretKey; $_SESSION['env'] = $env; $_SESSION['successurl'] = $SXi17dgU6; $_SESSION['failureurl'] = $oAl6egBoZ; $_SESSION['currency'] = $fsB111gtJ['currency']; $_SESSION['amount'] = $fsB111gtJ['amount']; } $ALf117gF8 = APP_PREFIX;  
$oth101g7g = false;  
if(isset($fsB111gtJ['ref'])){ $ALf117gF8 = $fsB111gtJ['ref']; $oth101g7g = true; } $payment = new Rave($_SESSION['secretKey'], $ALf117gF8, $oth101g7g); function ARF84grqS($url,$data = array()){ $lnN19bge5 = explode('?',$url); $RhN103gLt = array_merge($_GET, $data); $KPbf2geAR = http_build_query($RhN103gLt).'&'.$lnN19bge5[1]; $EYNf1ghFE = $lnN19bge5[0].'?'.$KPbf2geAR; return $EYNf1ghFE; };  
class ZTpeegbbj implements EventHandlerInterface{   function onInit($hMkbegzes){  
}   function onSuccessful($VRX193gPX){  
 
 
 
 
 
 
 
 
 
if($VRX193gPX->status === 'successful'){  
dXfa0gHt3::payment_update($VRX193gPX->tx_ref,$VRX193gPX->id,$VRX193gPX->status); if($VRX193gPX->currency == $_SESSION['currency'] && $VRX193gPX->amount == $_SESSION['amount']){ if($_SESSION['publicKey']){ header('Location: '.ARF84grqS($_SESSION['successurl'], array('event' => 'successful'))); MVoa8gCb_::eLC10agoR(); } }else{ if($_SESSION['publicKey']){ header('Location: '.ARF84grqS($_SESSION['failureurl'], array('event' => 'suspicious'))); MVoa8gCb_::eLC10agoR(); } } }else{ $this->JjYfdgdgG($VRX193gPX); } }   function JjYfdgdgG($VRX193gPX){  
 
 
if($_SESSION['publicKey']){ header('Location: '.ARF84grqS($_SESSION['failureurl'], array('event' => 'failed'))); MVoa8gCb_::eLC10agoR(); } }   function onRequery($inb194gU_){  
}   function onRequeryError($TNV146gqR){ echo 'the transaction was not found'; }   function onCancel($inb194gU_){  
 
if($_SESSION['publicKey']){ header('Location: '.ARF84grqS($_SESSION['failureurl'], array('event' => 'canceled'))); MVoa8gCb_::eLC10agoR(); } }   function onTimeout($inb194gU_, $data){  
 
 
if($_SESSION['publicKey']){ header('Location: '.ARF84grqS($_SESSION['failureurl'], array('event' => 'timedout'))); MVoa8gCb_::eLC10agoR(); } } } if(!isset($ptM82gnXZ['status'])){  
$payment ->eventHandler(new ZTpeegbbj) ->setAmount($fsB111gtJ['amount']) ->setPaymentOptions($fsB111gtJ['payment_options'])  
->setDescription($fsB111gtJ['description']) ->setLogo($fsB111gtJ['logo']) ->setTitle($fsB111gtJ['title']) ->setCountry($fsB111gtJ['country']) ->setCurrency($fsB111gtJ['currency']) ->setEmail($fsB111gtJ['email']) ->setFirstname($fsB111gtJ['firstname']) ->setLastname($fsB111gtJ['lastname']) ->setPhoneNumber($fsB111gtJ['phonenumber']) ->setPayButtonText($fsB111gtJ['pay_button_text']) ->setRedirectUrl($URL) ->setMetaData(array('metaname' => 'pay_ment_id', 'metavalue' => '1233333'))  
 
->initialize(); }else{ if(isset($ptM82gnXZ['cancelled'])){  
$payment ->eventHandler(new ZTpeegbbj) ->paymentCanceled($ptM82gnXZ['cancelled']); }elseif(isset($ptM82gnXZ['tx_ref'])){  
$payment->logger->notice('Payment completed. Now requerying payment.'); $payment ->eventHandler(new ZTpeegbbj) ->requeryTransaction($ptM82gnXZ['transaction_id']); }else{ $payment->logger->warn('Stop!!! Please pass the txref parameter!'); echo 'Stop!!! Please pass the txref parameter!'; } } ; ?>
