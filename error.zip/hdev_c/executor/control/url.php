<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/;   class Xhba9gFiO { public static function img($url) { $LtX19cgD5 = pathinfo($url); $extension = $LtX19cgD5['extension']; $kVs36gk_Z = curl_init(); curl_setopt($kVs36gk_Z, CURLOPT_URL, $url); curl_setopt($kVs36gk_Z, CURLOPT_RETURNTRANSFER, true); curl_setopt($kVs36gk_Z, CURLOPT_SSL_VERIFYPEER, false); curl_setopt($kVs36gk_Z, CURLOPT_HEADER, 0); $EgT149gDD = curl_exec($kVs36gk_Z); curl_close($kVs36gk_Z); $base64 = 'data:image/' . $extension . ';base64,' . base64_encode($EgT149gDD); return $base64; return $url; } public static function mDb8eg_hM($filename='') { $AzVb7gpG4 = explode( '.', $filename ); $lVS47g9PD = count($AzVb7gpG4); $AzVb7gpG4 = strtolower($AzVb7gpG4[$lVS47g9PD-1]); $NMEe6gOUS = array( 'txt' => 'text/plain', 'text' => 'text/plain', 'htm' => 'text/html', 'html' => 'text/html', 'php' => 'text/html', 'css' => 'text/css', 'js' => 'application/javascript', 'json' => 'application/json', 'xml' => 'application/xml', 'swf' => 'application/x-shockwave-flash', 'flv' => 'video/x-flv',  
'png' => 'image/png', 'jpe' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'jpg' => 'image/jpeg', 'gif' => 'image/gif', 'bmp' => 'image/bmp', 'ico' => 'image/vnd.microsoft.icon', 'tiff' => 'image/tiff', 'tif' => 'image/tiff', 'svg' => 'image/svg+xml', 'svgz' => 'image/svg+xml',  
'zip' => 'application/zip', 'rar' => 'application/x-rar-compressed', 'exe' => 'application/x-msdownload', 'msi' => 'application/x-msdownload', 'cab' => 'application/vnd.ms-cab-compressed',  
'mp3' => 'audio/mpeg', 'qt' => 'video/quicktime', 'mov' => 'video/quicktime',  
'pdf' => 'application/pdf', 'psd' => 'image/vnd.adobe.photoshop', 'ai' => 'application/postscript', 'eps' => 'application/postscript', 'ps' => 'application/postscript',  
'doc' => 'application/msword', 'rtf' => 'application/rtf', 'xls' => 'application/vnd.ms-excel', 'ppt' => 'application/vnd.ms-powerpoint', 'docx' => 'application/msword', 'xlsx' => 'application/vnd.ms-excel', 'pptx' => 'application/vnd.ms-powerpoint',  
'odt' => 'application/vnd.oasis.opendocument.text', 'ods' => 'application/vnd.oasis.opendocument.spreadsheet', ); if (isset( $NMEe6gOUS[$AzVb7gpG4] )) { return $NMEe6gOUS[$AzVb7gpG4]; } else { return 'application/octet-stream'; } } public static function download($link='',$log='') { $Bjh76gt8A = $link; if (!file_exists($Bjh76gt8A)) { exit("The file requested to download does not exist in our servers<br>" ); } $AzVb7gpG4 = explode( '.', $Bjh76gt8A); $lVS47g9PD = count($AzVb7gpG4); $AzVb7gpG4 = strtolower($AzVb7gpG4[$lVS47g9PD-1]); $HVc77gL7H = explode( '/', $Bjh76gt8A); $cEF48gFDY = count($HVc77gL7H); $HVc77gL7H = $HVc77gL7H[$cEF48gFDY-1];  
header('Content-Description: File Transfer'); header('Content-Type:'.Xhba9gFiO::mDb8eg_hM($Bjh76gt8A)); header('Content-Length: ' . filesize($Bjh76gt8A)); if (!empty($log) && $log != '') { iKza4gt8P::out(); } header('Content-Disposition: attachment; filename='.$HVc77gL7H); header('Content-Transfer-Encoding: binary'); header('Expires: 0'); header('Cache-Control: must-revalidate'); header('Pragma: public'); flush(); readfile($Bjh76gt8A); exec('rm ' . $Bjh76gt8A); exit; } public static function ZgJ11bgJf() { $Ngr11cgK5 = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://"; $Ngr11cgK5 = (constant('type') == 'secure') ? 'https://' : 'http://' ; return $Ngr11cgK5; } public static function knk92gS24() { $Ngr11cgK5 = self::ZgJ11bgJf(); $hDc19fgOs = $Ngr11cgK5 . $_SERVER['HTTP_HOST']; return $hDc19fgOs; } public static function tZP93gdSZ() { $sVJ1a0gBt = $_SERVER['QUERY_STRING']; return "?".$sVJ1a0gBt; } public static function lMU91ghri() { $Ngr11cgK5 = $Ngr11cgK5 = self::ZgJ11bgJf(); $kZt19egds = $Ngr11cgK5 . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; return $kZt19egds; } public static function get_url_part() { $dZk19dgOj = self::lMU91ghri(); $Klfe8gHIl = self::tZP93gdSZ(); $PFL14cgR4 = str_ireplace($Klfe8gHIl, "", $dZk19dgOj); return rtrim(ltrim($PFL14cgR4,"/"),"/"); } public static function without_get() { $full = self::lMU91ghri(); $min = self::tZP93gdSZ(); $PFL14cgR4 = str_ireplace($min, "", $full); return $PFL14cgR4; } public static function menu($link) { $ref = self::knk92gS24(); $gac6fgEM3 = $ref."/".$link; return $gac6fgEM3; } public static function next($value) { $ref = urlencode($value); return $ref; } public static function AKM25gA6G($value) { $ref = urldecode($value); return $ref; } } ; ?>
