<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/;   class hdev_pager { private static $limit = null; private static $ReI4cgGFE = null; private static $ZFm15eg8o = null; private static $url = null; function __construct($Oag136gHO="") { self::$url = Xhba9gFiO::menu($Oag136gHO); } public static function reset() { self::$limit = ""; } public static function set($page='',$rows='') { self::$ReI4cgGFE = (is_numeric($page)) ? $page : 1 ; 
self::$ZFm15eg8o = $rows; 
$start = $page; $end = $rows; if ($start == 0 || $start == 1 || empty($start) || !is_numeric($start)) { $start = 0; } if (isset($end) && is_numeric($end) && !empty($end) && $end != 0) { $DGebdgNNt = ($end*$start)-$end; if ($start == 0) { $DGebdgNNt = 0; } self::$limit = " LIMIT ".$DGebdgNNt.",".$end; }else{ self::$limit = ""; } } public static function limit($ref='get') { return self::$limit; } public static function page() { return self::$ReI4cgGFE; } public static function rows() { return self::$ZFm15eg8o; } public static function page_row($max=0,$aOc129gR3="Records") { $return = '
        <div class="border-top border-left border-right border-bottom p-1">
          <div class="row">
      '; $pYJ33grm9 = ceil($max/self::rows()); if ($pYJ33grm9 != 0) { $return .= '
          <div class="col-sm-2">
            <span class="btn btn-secondary">Page '.self::page()." in ".$pYJ33grm9.' pages</span>
            </div>'; $return .= '
          <div class="col-sm-8" align="center">
          <div class="btn-group iii_menu">'; $pg = self::page(); $prev = $pg-1; $next = $pg+1; if ($pg != 1) { $return .= '
            <button type="button" rel="external" url="'.self::$url.'" page="1" class="btn btn-sm btn-success pager_control"><i class="fa fa-angle-double-left"></i></button>
          '; } if ($prev > 0) { $return .= '
            <button type="button" rel="external" url="'.self::$url.'" page="'.$prev.'" class="btn btn-sm btn-success pager_control"><i class="fa fa-angle-left"></i></button>
          '; } for ($i=1; $i <= $pYJ33grm9; $i++) { $OZK95glUK = ($i==$pg) ? "btn-primary " : "btn-secondary" ; $Xzbb4ghA3 = ($i==$pg) ? "fa fa-file" : "fa fa-file-alt" ; $sre18bgNq = $i-$pg; if ($sre18bgNq > 3 || $sre18bgNq < -3) { }else{ $return .= '
              <button type="button" rel="external" url="'.self::$url.'" page="'.$i.'" class="btn btn-sm pager_control '.$OZK95glUK.'"><b><i class="'. "".'">'.$i.'</i></b></button>
              '; } } if ($next <= $pYJ33grm9) { $return .= '
            <button type="button" rel="external" url="'.self::$url.'" page="'.$next.'" class="btn btn-sm btn-success pager_control"><i class="fa fa-angle-right"></i></button>
          '; } if ($pg != $pYJ33grm9) { $return .= '
            <button type="button" rel="external" url="'.self::$url.'" page="'.$pYJ33grm9.'" class="btn btn-sm btn-success pager_control"><i class="fa fa-angle-double-right"></i></button>
          '; } $return .= '
            </div>
          </div>
          <div class="col-sm-2">
        '; if ($pg != $pYJ33grm9) { $rnz121gBd = $pg*self::rows(); $return .= "Showing ".$rnz121gBd." ".$aOc129gR3.", <br>In ".$max." ".$aOc129gR3."."; }elseif ($pg == $pYJ33grm9) { $return .= "Showing ".$max." ".$aOc129gR3.", <br>In ".$max." ".$aOc129gR3." ."; } $return .= '
          </div>
        '; }else{ $return .= '
          <div class="col-sm-12">
            --
          </div>
        '; } $return .= '
        </div>
      </div>
      <hr/>
      '; echo $return; } } ; ?>
