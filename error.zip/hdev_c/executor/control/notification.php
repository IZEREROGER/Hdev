<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/;   class kAGa6ghaY { public static function message($value,$oIP58gX9b='0',$ref="no") { if ($oIP58gX9b == "0" || $oIP58gX9b=="1") { $val = ""; $val .= "<script>alert('"; $val .= $value; $val .= "')</script>"; echo $val; } if ($oIP58gX9b == "1") { self::XgH132g45(Xhba9gFiO::lMU91ghri()); } if ($ref =="1") { $val = ""; $val .= "<script>alert('"; $val .= $value; $val .= "--- please contact the programmer : "; $val .= APP_PROGRAMMER['email']; $val .= "');</script>"; echo $val;  
} } public static function success($value='',$sEq1aegd4='.mod_close',$refresh='') { echo "<b class='text-success'>".$value."</b>"; echo "<script>
              setTimeout(function(){
                $('".$sEq1aegd4."').click();
                //attach();
              }, 1500);
              setTimeout(function(){"; if ($refresh == "") { echo "attach();"; }elseif ($refresh == 1) { echo "window.location.reload();"; } echo "
              }, 2000);
            </script>"; } public static function success_redirect($value='',$url="",$sEq1aegd4='.mod_close') { $url = (!empty($url)) ? $url : "" ; echo "<b class='text-success'>".$value."</b>"; self::XgH132g45($url); echo "<script>
              setTimeout(function(){
                $('".$sEq1aegd4."').click();
              }, 1500);
              setTimeout(function(){
                //attach('".$url."');
              }, 2000);
            </script>"; } public static function XgH132g45($var) { $olJ1adgCm = "<script>window.location.href='".$var."';</script>"; echo $olJ1adgCm; exit(); } public static function kHFd4g91d($tel='',$dIeecgGr5='') { if (!dXfa0gHt3::hMz10fgaf($tel) && !empty($dIeecgGr5)) { $data=array( "sender"=>constant('SMS_SENDER'), "recipients"=>"+25".$tel, "message"=>addslashes($dIeecgGr5), ); $url="https://www.intouchsms.co.rw/api/sendsms/.json"; $data=http_build_query($data); $username=constant('SMS_USERNAME'); $password=constant('SMS_PASSWORD'); $kVs36gk_Z=curl_init(); curl_setopt($kVs36gk_Z,CURLOPT_URL,$url); curl_setopt($kVs36gk_Z,CURLOPT_USERPWD,$username.":".$password); curl_setopt($kVs36gk_Z,CURLOPT_POST,true); curl_setopt($kVs36gk_Z,CURLOPT_RETURNTRANSFER,1); curl_setopt($kVs36gk_Z,CURLOPT_SSL_VERIFYPEER,0); curl_setopt($kVs36gk_Z,CURLOPT_POSTFIELDS,$data); $IsZ14bgfT=curl_exec($kVs36gk_Z); $EAlb2g7dp=curl_getinfo($kVs36gk_Z,CURLINFO_HTTP_CODE); curl_close($kVs36gk_Z);  
} } } ; ?>
