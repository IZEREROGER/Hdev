<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:03

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/; $Bhl12cgcz = array(   'login' => array( 'name'=>"Access to login", 'error'=>"Access denied to you to login" ), 'send_reset_code' => array( 'name'=>"Access to login", 'error'=>"Access denied to you to login" ), 'enter_code' => array( 'name'=>"Access to login", 'error'=>"Access denied to you to login" ), 'reset_password' => array( 'name'=>"Access to login", 'error'=>"Access denied to you to login" ), 'user_edit' => array( 'name'=>"Access to Edit User", 'error'=>"Access denied to you to Edit User" ), 'self_change_user_pwd' => array( 'name'=>"Access to Change user password", 'error'=>"Access denied to you to Change user password" ), 'stock_edit' => array( 'name'=>"Access to Edit User", 'error'=>"Access denied to you to Edit User" ), 'stock_reg' => array( 'name'=>"Access to Edit User", 'error'=>"Access denied to you to Edit User" ), 'stock_delete' => array( 'name'=>"Access to Edit User", 'error'=>"Access denied to you to Edit User" ), 'stock_recover' => array( 'name'=>"Access to Edit User", 'error'=>"Access denied to you to Edit User" ), 'location_select' => array( 'name'=>"Access to select location", 'error'=>"Access denied to you to select location" ), 'products_reg' => array( 'name'=>"Access to register cooperative product",
'error'=>"Access denied to you to register cooperative product" ), 'products_edit' => array( 'name'=>"Access to edit cooperative product", 'error'=>"Access denied to you to edit cooperative product" ), 'products_delete' => array( 'name'=>"Access to delete cooperative product", 'error'=>"Access denied to you to delete cooperative product" ), 'products_recover' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'stock_in' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'stock_in_bind' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'product_bind' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'stock_out' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'stock_in_edit' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'stock_in_delete' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'stock_in_recover' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'stock_out_delete' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'stock_out_back' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'cart_items' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'count_cart' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'add_to_cart' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'edit_to_cart' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'remove_cart' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'debit_reg' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'debit_delete' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'debit_pay_reg' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'debit_pay_delete' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'cash_received_reg' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'cash_received_delete' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'cash_paid_reg' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'cash_paid_delete' => array( 'name'=>"Access to recover cooperative member",
'error'=>"Access denied to you to recover cooperative product" ), 'cash_trans_reg' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'cash_trans_delete' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'cash_deposit_reg' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'cash_deposit_delete' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'momo_reg' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'momo_delete' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), 'send_sms' => array( 'name'=>"Access to recover cooperative member", 'error'=>"Access denied to you to recover cooperative product" ), );  
 
 
 
 
 
 
 
 
 
 
 
 
$tqq12dgBk = array( 'guest'=>array( 'enter_code', 'reset_password', 'send_reset_code', 'login'  , 'location_select' , ), 'super_admin'=> array(  
'login'  , 'user_edit'  , 'stock_edit', 'stock_delete', 'stock_recover', 'self_change_user_pwd' , 'location_select' , 'self_change_user_pwd' , 'stock_reg' ), 'admin'=> array(  
'login'  , 'user_edit'  , 'stock_edit', 'location_select' , 'self_change_user_pwd' , 'products_reg',  
 
'products_recover', 'search_member',  
'sales_view',  
'sales_recover', 'sales_approve', 'sales_reject', 'sales_delete_approve', 'sales_delete_reject', 'stock_in', 'stock_in_bind', 'product_bind', 'stock_out', 'stock_in_edit', 'stock_in_delete', 'stock_in_recover', 'stock_out_delete', 'stock_out_back', 'cart_items', 'count_cart', 'add_to_cart', 'edit_to_cart', 'remove_cart', 'debit_reg', 'debit_delete', 'debit_pay_reg', 'debit_pay_delete', 'cash_received_reg', 'cash_received_delete', 'cash_paid_reg', 'cash_paid_delete', 'cash_trans_reg', 'cash_trans_delete', 'cash_deposit_reg', 'cash_deposit_delete', 'momo_reg', 'momo_delete', 'send_sms' ), 'main_stock'=> array(  
'login'  , 'user_edit'  , 'stock_edit', 'location_select' , 'self_change_user_pwd' , 'products_reg', 'products_edit', 'products_delete', 'products_recover', 'search_member',  
'sales_view',  
'sales_recover', 'sales_approve', 'sales_reject', 'sales_delete_approve', 'sales_delete_reject', 'stock_in', 'stock_in_bind', 'product_bind', 'stock_out', 'stock_in_edit', 'stock_in_delete', 'stock_in_recover', 'stock_out_delete', 'stock_out_back', 'cart_items', 'count_cart', 'add_to_cart', 'edit_to_cart', 'remove_cart', 'debit_reg', 'debit_delete', 'debit_pay_reg', 'debit_pay_delete', 'cash_received_reg', 'cash_received_delete', 'cash_paid_reg', 'cash_paid_delete', 'cash_trans_reg', 'cash_trans_delete', 'cash_deposit_reg', 'cash_deposit_delete', 'momo_reg', 'momo_delete', 'send_sms' ), 'member'=> array(  
'login'  ,  
'location_select' , 'sales_reg', 'search_member', 'self_change_user_pwd' ), 'land_lord'=>array( 'login', 'houses_reg', 'location_select', 'house_edit', 'tenant_reg' , 'user_edit', 'self_change_user_pwd', 'house_delete' ), 'tenant'=> array( 'login'  , 'houses_rent' , 'req_house_prices' , 'location_select' , 'user_edit' , 'self_change_user_pwd' ), );  ?>
