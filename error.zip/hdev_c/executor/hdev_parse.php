<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:03

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/;  
if (!class_exists('BnHa7g834')) { class BnHa7g834 { private static $HXM15cg3o = Array(); private static $ePU108gj5 = null; private static $gYSe4gf4H = null; private static $lffdeg_2O = null; private static $OGodfgZUz = null;   public static function add($expression, $function, $method = ["get","post"]){ array_push(self::$HXM15cg3o, Array( 'expression' => $expression, 'function' => $function, 'method' => $method )); } public static function ePU108gj5($function) { self::$ePU108gj5 = $function; } public static function gYSe4gf4H($function) { self::$gYSe4gf4H = $function; } public static function all_req() { return self::$HXM15cg3o; } public static function unset_r($val) { unset(self::$HXM15cg3o[$val]); } public static function XFr85g7kn() { if (!is_null(self::$lffdeg_2O)) { return self::$lffdeg_2O; }else{ return "error"; } } public static function YsJ86gY1r() { if (!is_null(self::$OGodfgZUz)) { return self::$OGodfgZUz; }else{ return "error"; } } public static function reset2() { return self::$OGodfgZUz = null; } public static function ToG162gHX($basepath = '/', $lSl35gbT7 = false, $TPR192g7M = false, $FXdedgZi9 = false) {  
$ohR105g70 = parse_url($_SERVER['REQUEST_URI']); if (isset($ohR105g70['path']) && $ohR105g70['path'] != '/') { if ($TPR192g7M) { $path = $ohR105g70['path']; } else { $path = rtrim($ohR105g70['path'], '/'); } } else { $path = '/'; }  
$method = $_SERVER['REQUEST_METHOD']; $TLY109gpz = false; $bNR15bgb5 = false; foreach (self::$HXM15cg3o as $EBD15agRZ) {  
 
if ($basepath != '' && $basepath != '/') { $EBD15agRZ['expression'] = '('.$basepath.')'.$EBD15agRZ['expression']; }  
$EBD15agRZ['expression'] = '^'.$EBD15agRZ['expression'];  
$EBD15agRZ['expression'] = $EBD15agRZ['expression'].'$';  
if (preg_match('#'.$EBD15agRZ['expression'].'#'.($lSl35gbT7 ? '' : 'i'), $path, $Yjde0g2P2)) { $TLY109gpz = true;  
foreach ((array)$EBD15agRZ['method'] as $KMf27gmaG) {  
if (strtolower($method) == strtolower($KMf27gmaG)) { array_shift($Yjde0g2P2);  
if ($basepath != '' && $basepath != '/') { array_shift($Yjde0g2P2);  
} call_user_func_array($EBD15agRZ['function'], $Yjde0g2P2); $bNR15bgb5 = true; self::$lffdeg_2O = $EBD15agRZ['expression'];  
break; } } }  
if($bNR15bgb5&&!$FXdedgZi9){ break; } }  
if (!$bNR15bgb5) {  
if ($TLY109gpz) { if (self::$gYSe4gf4H) { call_user_func_array(self::$gYSe4gf4H, Array($path,$method)); } } else { if (self::$ePU108gj5) { call_user_func_array(self::$ePU108gj5, Array($path)); } } } } public static function access($basepath = '/', $lSl35gbT7 = false, $TPR192g7M = false, $FXdedgZi9 = false, $url='rasms_server_1234_url') {  
if ($url!='rasms_server_1234_url') { $ohR105g70 = parse_url($url); } else { $ohR105g70 = parse_url($_SERVER['REQUEST_URI']); } if (isset($ohR105g70['path']) && $ohR105g70['path'] != '/') { if ($TPR192g7M) { $path = $ohR105g70['path']; } else { $path = rtrim($ohR105g70['path'], '/'); } } else { $path = '/'; }  
$method = $_SERVER['REQUEST_METHOD']; $TLY109gpz = false; $bNR15bgb5 = false; foreach (self::$HXM15cg3o as $EBD15agRZ) {  
 
if ($basepath != '' && $basepath != '/') { $EBD15agRZ['expression'] = '('.$basepath.')'.$EBD15agRZ['expression']; }  
$EBD15agRZ['expression'] = '^'.$EBD15agRZ['expression'];  
$EBD15agRZ['expression'] = $EBD15agRZ['expression'].'$';  
if (preg_match('#'.$EBD15agRZ['expression'].'#'.($lSl35gbT7 ? '' : 'i'), $path, $Yjde0g2P2)) { $TLY109gpz = true;  
foreach ((array)$EBD15agRZ['method'] as $KMf27gmaG) {  
if (strtolower($method) == strtolower($KMf27gmaG)) { array_shift($Yjde0g2P2);  
if ($basepath != '' && $basepath != '/') { array_shift($Yjde0g2P2);  
} if ($url!='rasms_server_1234_url') { self::$OGodfgZUz = ltrim(rtrim($EBD15agRZ['expression'],"$"),"^"); } else { self::$lffdeg_2O = ltrim(rtrim($EBD15agRZ['expression'],"$"),"^"); } $eKo70gZbI = true;  
break; } } }  
if($bNR15bgb5){ echo $EBD15agRZ['expression']."<br>"; break; } }  
if (!isset($eKo70gZbI)) {  
if ($url!='rasms_server_1234_url') { self::$OGodfgZUz = null; } else { self::$lffdeg_2O = null; } } } } }; ?>
