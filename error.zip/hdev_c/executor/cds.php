<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/; $aHC13dgLD = __DIR__; $YUM13agBN = str_ireplace('\\', "/", $aHC13dgLD).'/qr_3/roger_cd/qrlib.php'; require_once $YUM13agBN; $PpZ2bg1RL = 0xFFFFFF; $PZd7bgsOp = 0x2F64B3; 
 
$var = dXfa0gHt3::gAC4fgS8T(urldecode($Pke66g2V4)); $chS180g2z = str_ireplace("\t", "", $var);  
$mZm56gZM9 = QRcode::png($chS180g2z, false, 'm', 4, 3, false, $PpZ2bg1RL, $PZd7bgsOp);  ?>
