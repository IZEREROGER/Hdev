<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:03

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661816)/* Founder*/; define("APP_NAME", "RASMS System V.5"); define("APP_VERSION", "1.1"); define('APP_PROGRAMMER', ['name'=>'Izere Hirwa Roger','email'=>'izereroger1@gmail.com']); define('db',"o_le"); define('db_preview',"o_le_preview"); define('dbpass_preview', ''); define('dbusr_preview', 'root'); define('dbpass', ''); define('dbusr', 'root'); define('db_remote', 'st_soft'); define('dbusr_remote', 'roger'); define('dbpass_remote', 'qwe'); define('dbport_remote', '3309'); define('aGF167gEB', 'rasms_mtvet');  
define("tHK159gB_", "hdev_c3538TVVTQU1WVSBUVkVUIFNDSE9PTA=="); define('ad_us_pw', "hdev_79b11Li4uUk9HLi4=");  
 ?>
