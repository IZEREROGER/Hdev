<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661817)/* Founder*/;$hruags1006='CiAgPCEtLSBDb250ZW50IFdyYXBwZXIuIENvbnRhaW5zIHBhZ2UgY29udGVudCAtLT4KICA8ZGl2IGNsYXNzPSJjb250ZW50LXdyYXBwZXIiPgogICAgICA8ZGl2IGNsYXNzPSJwYWdlLWhlYWRlciI+CiAgICAgICAgPGRpdiBjbGFzcz0icm93Ij4KICAgICAgICAgIDxkaXYgY2xhc3M9ImNvbC1tZC00IGNvbC1zbS0xMiI+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9InRpdGxlIj4KICAgICAgICAgICAgICA8aDQgc3R5bGU9ImZvbnQtc3R5bGU6IG9ibGlxdWU7Ij58fAogICAgICAgICAgICAgICAg';$nbchpa1007='IHx8CiAgICAgICAgICAgICAgPC9oND4KICAgICAgICAgICAgPC9kaXY+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDxkaXYgY2xhc3M9ImNvbC1tZC00IGNvbC1zbS0xMiI+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9InRpdGxlIj4KICAgICAgICAgICAgICA8aDQ+';$fbcanw1008='PC9oND4KICAgICAgICAgICAgPC9kaXY+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDxkaXYgY2xhc3M9ImNvbC1tZC00IGNvbC1zbS0xMiB0ZXh0LXJpZ2h0Ij4KICAgICAgICAgICAgPG5hdiBhcmlhLWxhYmVsPSJicmVhZGNydW1iIiByb2xlPSJuYXZpZ2F0aW9uIj4KICAgICAgICAgICAgICA8b2wgY2xhc3M9ImJyZWFkY3J1bWIiPgogICAgICAgICAgICAgICAgPGxpIGNsYXNzPSJicmVhZGNydW1iLWl0ZW0iPjxhIGhyZWY9Ig==';$wptrsk1009='Ij4=';$grsyhy1010='PC9hPjwvbGk+CiAgICAgICAgICAgICAgICA8bGkgY2xhc3M9ImJyZWFkY3J1bWItaXRlbSBhY3RpdmUiIGFyaWEtY3VycmVudD0icGFnZSI+';$xsitgl1011='PC9saT4KICAgICAgICAgICAgICA8L29sPgogICAgICAgICAgICA8L25hdj4KICAgICAgICAgIDwvZGl2PgogICAgICAgIDwvZGl2PgogICAgICA8L2Rpdj4KICAgIDwhLS0gTWFpbiBjb250ZW50IC0tPgogICAgPGRpdiBjbGFzcz0ibWItMTAiPgogICAgICAgIA==';$aoahwu1012='CiAgICA8L2Rpdj4KCiAgICA8IS0tIC8uY29udGVudCAtLT4KICA8L2Rpdj4KICA8IS0tIC8uY29udGVudC13cmFwcGVyIC0tPgo='; if ((!isset($_GET) || !isset($_GET['tb']) || $_GET['tb'] != "ok") && !isset($qFfc6gCtd)): ;print(base64_decode($hruags1006)); switch (iKza4gt8P::fid()) { case 'main_stock': echo "Main stock"; break; case 'admin': echo "Sub Stock"; break; case 'super_admin': echo "Main System administrator"; break; default: echo "Guest"; break; } ;print(base64_decode($nbchpa1007)); echo $_SESSION['act_url'][0]; print(base64_decode($fbcanw1008)); echo Xhba9gFiO::knk92gS24(); print(base64_decode($wptrsk1009)); echo sBpa3gfRp::on("menu",'home') ;print(base64_decode($grsyhy1010)); echo $_SESSION['act_url'][0]; print(base64_decode($xsitgl1011)); if (!empty($_SESSION['act_url'])) { if (!empty($_SESSION['act_url'][0]) && !empty($_SESSION['act_url'][1])) { if (file_exists($_SESSION['act_url'][1].".php")) { if (pITa5gNqG::ZRz1a1gbc($_SESSION['act_url'][0],"user") == "y") { include $_SESSION['act_url'][1].".php"; }else{  
include 'error.php'; } }else{  
include 'error.php'; } }else{   include 'error.php'; } }else{  
include 'error.php'; } ;print(base64_decode($aoahwu1012)); endif ; ?>
