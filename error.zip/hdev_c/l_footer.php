<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:03

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661817)/* Founder*/;$jwfvca1134='PCEtLSBqUXVlcnkgLS0+CjxzY3JpcHQgc3JjPSI=';$lrpobx1135='Ij48L3NjcmlwdD4KICA8IS0tIGpzIC0tPgogIDxzY3JpcHQgc3JjPSI=';$pjdcgk1136='Ij48L3NjcmlwdD4KICA8c2NyaXB0IHNyYz0i';$ohtkom1137='Ij48L3NjcmlwdD4KICA8c2NyaXB0IHNyYz0i';$cjfuky1138='Ij48L3NjcmlwdD4KICA8c2NyaXB0IHNyYz0i';$nfpqgj1139='Ij48L3NjcmlwdD4KPCEtLSBTd2VldEFsZXJ0MiAtLT4KPHNjcmlwdCBzcmM9Ig==';$tcmxes1140='Ij48L3NjcmlwdD4KICA8c2NyaXB0IHR5cGU9InRleHQvamF2YXNjcmlwdCI+CiAgICAgICAgZnVuY3Rpb24gYXR0YWNoKGFhPScnKSB7CiAgICAgIHdpbmRvdy5yZWxvYWQoKTsKICAgIH0KICAgIGZ1bmN0aW9uIGxvZ2luKCkgewogICAgICAvL2FsZXJ0KCdoZWxsb29vb29vJyk7CiAgICAgICAgICBjb25zdCBUb2FzdCA9IFN3YWwubWl4aW4oewogICAgICAgICAgdG9hc3Q6IHRydWUsCiAgICAgICAgICBwb3NpdGlvbjogJ3RvcC1lbmQnLAogICAgICAgICAgc2hvd0NvbmZpcm1CdXR0b246IGZzYXZlLAogICAgICAgICAgdGltZXI6IDMwMDAKICAgICAgICB9KTsKICAgICAgICB2YXIgZm9ybURhdGEgPSBqUXVlcnkoJyNsb2dpbl9mb3JtJykuc2VyaWFsaXplKCk7CiAgICAgICAgJC5hamF4KHsKICAgICAgICAgIHR5cGU6ICJQT1NUIiwKICAgICAgICAgIHVybDogIg==';$gbbvxe1141='IiwKICAgICAgICAgIGRhdGE6IGZvcm1EYXRhLAogICAgICAgICAgYmVmb3JlU2VuZDogZnVuY3Rpb24oKXsKICAgICAgICAgICAgLy8gU2hvdyBpbWFnZSBjb250YWluZXIKICAgICAgICAgICAgJCgiI2ZzYXZlIikuaGlkZSgpOwogICAgICAgICAgICAkKCIud2FpdCIpLnNob3coKTsKICAgICAgICAgICB9LAogICAgICAgICAgc3VjY2VzczpmdW5jdGlvbihodG1sKXsKICAgICAgICAgICAgaWYgKGh0bWwgPT0gJ29rJyl7CiAgICAgICAgICAgICAgVG9hc3QuZmlyZSh7CiAgICAgICAgICAgICAgICB0eXBlOiAnc3VjY2VzcycsCiAgICAgICAgICAgICAgICB0aXRsZTogJw==';$ngqbng1142='JwogICAgICAgICAgICAgIH0pOwogICAgICAgICAgICAgIHZhciBkZWxheSA9IDEwMDA7CiAgICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpewogICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmPSc=';$btlcrq1143='JzsKICAgICAgICAgICAgICB9LCBkZWxheSk7CiAgICAgICAgICAgIH1lbHNlCiAgICAgICAgICAgIHsKICAgICAgICAgICAgLy9hbGVydChodG1sKTsKICAgICAgICAgICAgICBUb2FzdC5maXJlKHsKICAgICAgICAgICAgICAgIHR5cGU6ICdlcnJvcicsCiAgICAgICAgICAgICAgICB0aXRsZTogJw==';$fkiylf1144='JwogICAgICAgICAgICAgIH0pOwogICAgICAgICAgICAgICQoIi53YWl0IikuaGlkZSgpOwogICAgICAgICAgICAgICQoIiNmc2F2ZSIpLnNob3coKTsKICAgICAgICAgICAgfQogICAgICAgICAgfSwKICAgICAgICAgIGNvbXBsZXRlOmZ1bmN0aW9uKGh0bWwpewogICAgICAgICAgICAvLyBIaWRlIGltYWdlIGNvbnRhaW5lcgogICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKXsKICAgICAgICAgICAgICAvLyQoIiNmc2F2ZSIpLnNob3coKTsKICAgICAgICAgICAgICAkKCIud2FpdCIpLmhpZGUoKTsKICAgICAgICAgICAgfSwgMzAwMCk7CiAgICAgICAgICAgfQogICAgICAgIH0pOwogICAgfSAKICA8L3NjcmlwdD4KPC9ib2R5Pgo8L2h0bWw+';print(base64_decode($jwfvca1134)); echo Xhba9gFiO::menu('src/plugins/jquery/jquery.min.js');print(base64_decode($lrpobx1135)); echo Xhba9gFiO::menu('vendors/scripts/core.js');print(base64_decode($pjdcgk1136)); echo Xhba9gFiO::menu('vendors/scripts/script.min.js');print(base64_decode($ohtkom1137)); echo Xhba9gFiO::menu('vendors/scripts/process.js');print(base64_decode($cjfuky1138)); echo Xhba9gFiO::menu('vendors/scripts/layout-settings.js');print(base64_decode($nfpqgj1139)); echo Xhba9gFiO::menu('src/plugins/sweetalert2/sweetalert2.min.js');print(base64_decode($tcmxes1140)); echo Xhba9gFiO::menu('login_i');print(base64_decode($gbbvxe1141)); echo sBpa3gfRp::on("validation",'signedin'); print(base64_decode($ngqbng1142)); echo Xhba9gFiO::menu("r/home");print(base64_decode($btlcrq1143)); echo sBpa3gfRp::on("validation",'log_fair'); print(base64_decode($fkiylf1144)); ?>
