<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:03

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661817)/* Founder*/;$iqaocw1090='PCFET0NUWVBFIGh0bWw+CjxodG1sIGxhbmc9ImVuIj4KPGhlYWQ+CiAgPCEtLSBCYXNpYyBQYWdlIEluZm8gLS0+CiAgPG1ldGEgY2hhcnNldD0idXRmLTgiPgogIDxtZXRhIG5hbWU9InZpZXdwb3J0IiBjb250ZW50PSJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MSI+CiAgPG1ldGEgbmFtZT0idGhlbWUtY29sb3IiIGNvbnRlbnQ9InJnYigwLDEyMywyNTUpIi8+CiAgPHRpdGxlPg==';$wdowsi1091='PC90aXRsZT4KICA8bGluayByZWw9Im1hbmlmZXN0IiBocmVmPSI=';$ydqkru1092='Ij4KICA8c2NyaXB0PgogICAgICAvL2lmIGJyb3dzZXIgc3VwcG9ydCBzZXJ2aWNlIHdvcmtlcgogICAgICBpZignc2VydmljZVdvcmtlcicgaW4gbmF2aWdhdG9yKSB7CiAgICAgICAgbmF2aWdhdG9yLnNlcnZpY2VXb3JrZXIucmVnaXN0ZXIoJw==';$rceerc1093='Jyk7CiAgICAgIH07CiAgPC9zY3JpcHQ+CiAgPCEtLSBTaXRlIGZhdmljb24gLS0+CiAgPGxpbmsgcmVsPSJhcHBsZS10b3VjaC1pY29uIiBocmVmPSI=';$btuyxi1094='Ij4KICA8bGluayByZWw9Imljb24iIHR5cGU9ImltYWdlL3BuZyIgaHJlZj0i';$tgauws1095='Ij4KCiAgPCEtLSBNb2JpbGUgU3BlY2lmaWMgTWV0YXMgLS0+CiAgPG1ldGEgbmFtZT0idmlld3BvcnQiIGNvbnRlbnQ9IndpZHRoPWRldmljZS13aWR0aCwgaW5pdGlhbC1zY2FsZT0xLCBtYXhpbXVtLXNjYWxlPTEiPgoKICA8IS0tIEdvb2dsZSBGb250IC0tPgogIDxsaW5rIGhyZWY9Imh0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzMj9mYW1pbHk9SW50ZXI6d2dodEAzMDA7NDAwOzUwMDs2MDA7NzAwOzgwMCZkaXNwbGF5PXN3YXAiIHJlbD0ic3R5bGVzaGVldCI+CiAgPCEtLSBDU1MgLS0+CiAgPGxpbmsgcmVsPSJzdHlsZXNoZWV0IiB0eXBlPSJ0ZXh0L2NzcyIgaHJlZj0i';$xrtwrn1096='Ij4KICA8bGluayByZWw9InN0eWxlc2hlZXQiIHR5cGU9InRleHQvY3NzIiBocmVmPSI=';$qoskma1097='Ij4KICA8bGluayByZWw9InN0eWxlc2hlZXQiIHR5cGU9InRleHQvY3NzIiBocmVmPSI=';$mjcarp1098='Ij4KICA8bGluayByZWw9InN0eWxlc2hlZXQiIHR5cGU9InRleHQvY3NzIiBocmVmPSI=';$wppfjs1099='Ij4KCjwvaGVhZD4KPGJvZHkgY2xhc3M9ImhlYWRlci1kYXJrIj4KICA8ZGl2IGNsYXNzPSJwcmUtbG9hZGVyIj4KICAgIDxkaXYgY2xhc3M9InByZS1sb2FkZXItYm94Ij4KICAgICAgPGNlbnRlcj4KICAgICAgPGRpdiBjbGFzcz0ibG9hZGVyLWxvZ28iPjxpbWcgc3JjPSI=';$ooaxha1100='IiBhbHQ9IiI+PGJyPjxpbWcgc3JjPSI=';$uxxboc1101='IiBhbHQ9IiI+PC9kaXY+PC9jZW50ZXI+CiAgICAgIDxkaXYgY2xhc3M9ImxvYWRlci1sb2dvIj48L2Rpdj4KICAgICAgPGRpdiBjbGFzcz0nbG9hZGVyLXByb2dyZXNzJyBpZD0icHJvZ3Jlc3NfZGl2Ij4KICAgICAgICA8ZGl2IGNsYXNzPSdiYXInIGlkPSdiYXIxJz48L2Rpdj4KICAgICAgPC9kaXY+CiAgICAgIDxkaXYgY2xhc3M9J3BlcmNlbnQnIGlkPSdwZXJjZW50MSc+MCU8L2Rpdj4KICAgICAgPGRpdiBjbGFzcz0ibG9hZGluZy10ZXh0Ij4KICAgICAgICBMb2FkaW5nLi4uCiAgICAgIDwvZGl2PgogICAgPC9kaXY+CiAgPC9kaXY+CiAgPGRpdiBjbGFzcz0ibWFpbi1jb250YWluZXIiPgogICAgPGRpdiBjbGFzcz0ieHMtcGQtMjAtMTAgcGQtbHRyLTIwIj4=';print(base64_decode($iqaocw1090)); echo APP_NAME; print(base64_decode($wdowsi1091)); echo Xhba9gFiO::menu('manifest.json'); print(base64_decode($ydqkru1092)); echo Xhba9gFiO::menu('sw_ct.js'); print(base64_decode($rceerc1093)); echo Xhba9gFiO::menu('icon/og_image.png'); print(base64_decode($btuyxi1094)); echo Xhba9gFiO::menu('icon/og_image.png'); print(base64_decode($tgauws1095)); echo Xhba9gFiO::menu('vendors/styles/core.css'); print(base64_decode($xrtwrn1096)); echo Xhba9gFiO::menu('vendors/styles/icon-font.min.css'); print(base64_decode($qoskma1097)); echo Xhba9gFiO::menu('src/plugins/jvectormap/jquery-jvectormap-2.0.3.css'); print(base64_decode($mjcarp1098)); echo Xhba9gFiO::menu('vendors/styles/style.css'); print(base64_decode($wppfjs1099)); echo Xhba9gFiO::menu('icon/ghost.gif'); print(base64_decode($ooaxha1100)); echo Xhba9gFiO::menu('icon/og_image.png'); print(base64_decode($uxxboc1101)); ?>
