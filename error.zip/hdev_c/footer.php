<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:03

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661817)/* Founder*/;$uwitjl1013='ICA8IS0tIGpzIC0tPgogIDxzY3JpcHQgc3JjPSI=';$xthpav1014='Ij48L3NjcmlwdD4KICA8c2NyaXB0IHNyYz0i';$oxpmst1015='Ij48L3NjcmlwdD4KICA8c2NyaXB0IHNyYz0i';$thnmpq1016='Ij48L3NjcmlwdD4KICA8c2NyaXB0IHNyYz0i';$ipvlcu1017='Ij48L3NjcmlwdD4KICA8c2NyaXB0IHNyYz0i';$gnyugi1018='Ij48L3NjcmlwdD4KICA8c2NyaXB0IHNyYz0i';$qfhvlb1019='Ij48L3NjcmlwdD4KICA8c2NyaXB0IHNyYz0i';$kqnndw1020='Ij48L3NjcmlwdD4KICA8c2NyaXB0IHNyYz0i';$jnyuyp1021='Ij48L3NjcmlwdD4KICA8c2NyaXB0IHNyYz0i';$qphydm1022='Ij48L3NjcmlwdD4KICA8c2NyaXB0IHNyYz0i';$axsihv1023='Ij48L3NjcmlwdD4KPHNjcmlwdCB0eXBlPSJ0ZXh0L2phdmFzY3JpcHQiPgoKICAvL3NtX250KCk7CiAgZnVuY3Rpb24gdXBkYXRlX2RhdGF0YWJsZSgpIHsKICAgICAKCiAgfQogIGZ1bmN0aW9uIGF0dGFjaChjdXI9JycpIHsKICAgIC8vYWxlcnQoY3VyKTsKICAgIGlmIChjdXIgPT0gIiIpIHsKICAgICAgY3VyID0gd2luZG93LmxvY2F0aW9uLmhyZWY7CiAgICB9CiAgICAkKCcjbWVudV9sb2FkZXInKS5odG1sKCc8ZGl2IGNsYXNzPSJwcm9jZXNzLWxvYWRlciI+PC9kaXY+Jyk7CiAgICB2YXIgcmVzdCA9ICBjdXIuc3BsaXQoIj8iKTsKICAgICB4aHR0cCA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpOwogICAgIHhodHRwLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uKCkgewogICAgICAgIGlmICh0aGlzLnJlYWR5U3RhdGUgPT0gNCkgewogICAgICAgICAgaWYgKHRoaXMuc3RhdHVzID09IDIwMCkgewogICAgICAgICAgICAkKCdib2R5ICNhcHBfYm9keScpLmh0bWwodGhpcy5yZXNwb25zZVRleHQpOwogICAgICAgICAgICAkKCcjbWVudV9sb2FkZXInKS5odG1sKCc8IS0tbG9hZGVyLS0+Jyk7CiAgICAgICAgICAgIHVwZGF0ZV9kYXRhdGFibGUoKTsKICAgICAgICAgIH0KICAgICAgICAgIGlmICh0aGlzLnN0YXR1cyA9PSA0MDQpIHsKICAgICAgICAgICAgLy93aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7CiAgICAgICAgICB9CiAgICAgICAgfQogICAgICB9CiAgICAgIHhodHRwLm9wZW4oIkdFVCIsICIiK3Jlc3RbMF0rIi9hL2IvYyIsIHRydWUpOwogICAgICB4aHR0cC5zZW5kKCk7CiAgfQoKICAkbG9hZF9zdGF0dXM9ICQoJzxzcGFuPjxpbWcgc3JjPSI=';$ihrpgu1024='Ii8+PC9zcGFuPjxpPiZuYnNwOyZuYnNwO3dhaXQuLi4hISE8L2k+Jyk7CiAgJHNhdmVkID0gJCgnPHNwYW4gY2xhc3M9InRleHQtc3VjY2VzcyI+';$mecwls1025='PC9zcGFuPicpOwogICRtaW5fd2FpdCA9ICQoJzxzcGFuIGNsYXNzPSJ0ZXh0LXN1Y2Nlc3MiPg==';$qdgypx1026='PC9zcGFuPicpOwogJChkb2N1bWVudCkucmVhZHkoZnVuY3Rpb24oKXsgCiAgdXBkYXRlX2RhdGF0YWJsZSgpOwoKICAgICQoZG9jdW1lbnQpLm9uKCdjbGljaycsJy5wYWdlcl9jb250cm9sJyxmdW5jdGlvbihlKSB7CiAgICAgICAgdmFyIHVycj0kKHRoaXMpLmF0dHIoInVybCIpOwogICAgICAgIHZhciBwZ2c9JCh0aGlzKS5hdHRyKCJwYWdlIik7CiAgICAgICAgdmFyIGxjYyA9IHVycisnLycrcGdnOwogICAgICAgIGF0dGFjaChsY2MpOwogICAgfSk7ICAgIAogCiAgfSk7Cjwvc2NyaXB0PjwhLS0KPHNjcmlwdCBzcmM9Ig==';$kdltin1027='Ij48L3NjcmlwdD4tLT4KPC9ib2R5Pgo8L2h0bWw+Cgo=';print(base64_decode($uwitjl1013)); echo Xhba9gFiO::menu('vendors/scripts/core.js'); print(base64_decode($xthpav1014)); echo Xhba9gFiO::menu('vendors/scripts/script.min.js'); print(base64_decode($oxpmst1015)); echo Xhba9gFiO::menu('vendors/scripts/process.js'); print(base64_decode($thnmpq1016)); echo Xhba9gFiO::menu('vendors/scripts/layout-settings.js'); print(base64_decode($ipvlcu1017)); echo Xhba9gFiO::menu('src/plugins/jQuery-Knob-master/jquery.knob.min.js'); print(base64_decode($gnyugi1018)); echo Xhba9gFiO::menu('src/plugins/highcharts-6.0.7/code/highcharts.js'); print(base64_decode($qfhvlb1019)); echo Xhba9gFiO::menu('src/plugins/highcharts-6.0.7/code/highcharts-more.js'); print(base64_decode($kqnndw1020)); echo Xhba9gFiO::menu('src/plugins/jvectormap/jquery-jvectormap-2.0.3.min.js'); print(base64_decode($jnyuyp1021)); echo Xhba9gFiO::menu('src/plugins/jvectormap/jquery-jvectormap-world-mill-en.js'); print(base64_decode($qphydm1022)); echo Xhba9gFiO::menu('vendors/scripts/dashboard2.js'); print(base64_decode($axsihv1023)); echo Xhba9gFiO::img(Xhba9gFiO::menu('dist/img/loading2.gif'));print(base64_decode($ihrpgu1024)); echo sBpa3gfRp::on("validation","saved"); print(base64_decode($mecwls1025)); echo sBpa3gfRp::on("validation","loading"); print(base64_decode($qdgypx1026)); echo Xhba9gFiO::menu('script-1'); print(base64_decode($kdltin1027)); ?>
