<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661815)/* Founder*/;$mbayom444='CjxkaXYgaWQ9ImFwcF9kYXRhIj4KICAgICAgPGRpdiBjbGFzcz0icm93Ij4KICAgICAgICAgIDxkaXYgY2xhc3M9ImNvbC1zbS0xMiI+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9ImNhcmQiIHN0eWxlPSJoZWlnaHQ6IDEwMCU7Ij4KICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSJjYXJkLWhlYWRlciI+PGg1PlByb2R1Y3RzIGluIHN0b2NrIHN0YXR1czwvaDU+CiAgICAgICAgICAgICAgPC9kaXY+CiAgICAgICAgICAgICAgPGRpdiBjbGFzcz0iY2FyZC1ib2R5IHRhYmxlLXJlc3BvbnNpdmUgcC0yIj4KICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzPSJkYXRhLXRhYmxlIHRhYmxlIHRhYmxlLWJvcmRlcmVkIHRhYmxlLWhvdmVyIHRhYmxlLXN0cmlwZWQgdGV4dC1ub3dyYXAiIGlkPSIiPgogICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3M9ImJvcmRlci10b3AiPgogICAgICAgICAgICAgICAgICAgIDx0cj4KICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz0idGFibGUtcGx1cyBkYXRhdGFibGUtbm9zb3J0Ij5SZWcuIG5vPC90aD4KICAgICAgICAgICAgICAgICAgICAgIDx0aD5Qcm9kdWN0PC90aD4KICAgICAgICAgICAgICAgICAgICAgIDx0aD5RdWFudGl0eTwvdGg+CiAgICAgICAgICAgICAgICAgICAgICA=';$uaebnt445='CiAgICAgICAgICAgICAgICAgICAgICA8dGg+';$tgavpj446='PC90aD4KICAgICAgICAgICAgICAgICAgICAgIA==';$teuihu447='IAogICAgICAgICAgICAgICAgICAgIDwvdHI+CiAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+CiAgICAgICAgICAgICAgICAgIDx0Ym9keT4KICAgICAgICAgICAgICAgICAgICA=';$ynguhq448='CiAgICAgICAgICAgICAgICAgICAgPHRyPgogICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzPSJ0YWJsZS1wbHVzIj4KICAgICAgICAgICAgICAgICAgICAgICAg';$whdvfo449='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPgogICAgICAgICAgICAgICAgICAgICAgPHRkPgogICAgICAgICAgICAgICAgICAgICAgICA=';$aedoct450='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPgogICAgICAgICAgICAgICAgICAgICAgPHRkPgogICAgICAgICAgICAgICAgICAgICAgICA=';$pxerrf451='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAg';$sxgphs452='CiAgICAgICAgICAgICAgICAgICAgICA8dGQ+CiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9ImJ0bi1ncm91cCBidG4tZ3JvdXAtc20iPgogICAgICAgICAgICAgICAgICAgICAgICAgICA=';$obscts453='CiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPSJidXR0b24iIHJlbD0iZXh0ZXJuYWwiIGNsYXNzPSJidG4gYnRuLXN1Y2Nlc3MgcHJvZF9lZGl0IiBkYXRhLXRvZ2dsZT0ibW9kYWwiIGRhdGEtdGFyZ2V0PSIubW9kYWwtZWRpdCI+PGkgY2xhc3M9ImZhIGZhLWVkaXQiPjwvaT4g';$igrkbr454='IDwvYnV0dG9uPgogICAgICAgICAgICAgICAgICAgICAgICAgICA=';$fqlrhu455='CiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPSJidXR0b24iIGhhc2g9Ig==';$uqvhhg456='IiBkYXRhPSI=';$qupusn457='IiByZWw9ImV4dGVybmFsIiBjbGFzcz0iYnRuIGJ0bi1kYW5nZXIgcHJvZF9kZWxldGUiZGF0YS10b2dnbGU9Im1vZGFsIiBkYXRhLXRhcmdldD0iLm1vZGFsLWRlbGV0ZSI+PGkgY2xhc3M9ImZhIGZhLXRyYXNoIj48L2k+IA==';$vrkrmg458='IDwvYnV0dG9uPgogICAgICAgICAgICAgICAgICAgICAgICAgICA=';$rvcwdf459='CiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICAgICAgICAgICAgPC90ZD4KICAgICAgICAgICAgICAgICAgICAgIA==';$eyydbt460='IAogICAgICAgICAgICAgICAgICAgIDwvdHI+CiAgICAgICAgICAgICAgICAgIA==';$qoiutn461='CiAgICAgICAgICAgICAgICAgIDwvdGJvZHk+CiAgICAgICAgICAgICAgICA8L3RhYmxlPgogICAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDwvZGl2PgogICAgICAgICAgPCEtLSAvLmNvbCAtLT4KICAgICAgPC9kaXY+CjwvZGl2Pg==';  
 
;print(base64_decode($mbayom444)); if (dXfa0gHt3::service('scv')): ;print(base64_decode($uaebnt445)); echo sBpa3gfRp::on("form","action"); print(base64_decode($tgavpj446)); endif ;print(base64_decode($teuihu447)); $COV38gesi = dXfa0gHt3::in_stock();  
 foreach ($COV38gesi AS $stock) { $pJK4bgj3P = new CSRF_Protect(); $NcA18fg9Z = $pJK4bgj3P->DbF83gRna(); $product = dXfa0gHt3::products($stock['p_id'],['data']); print(base64_decode($ynguhq448)); echo $stock["p_id"]; print(base64_decode($whdvfo449)); echo $product['p_name']; print(base64_decode($aedoct450)); echo $stock['qty'].' '.$product['p_unit']; print(base64_decode($pxerrf451)); if (dXfa0gHt3::service('scv')): ;print(base64_decode($sxgphs452)); if (dXfa0gHt3::service('products_edit')): ;print(base64_decode($obscts453)); echo sBpa3gfRp::on("form","edit"); print(base64_decode($igrkbr454)); endif ; if (dXfa0gHt3::service('products_delete')): ;print(base64_decode($fqlrhu455)); echo $NcA18fg9Z; print(base64_decode($uqvhhg456)); echo $reject; print(base64_decode($qupusn457)); echo sBpa3gfRp::on("form","delete"); print(base64_decode($vrkrmg458)); endif ;print(base64_decode($rvcwdf459)); endif ;print(base64_decode($eyydbt460)); } ;print(base64_decode($qoiutn461)); ?>
