<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661815)/* Founder*/;$ncicdy462='CiAgICA8ZGl2IGNsYXNzPSJwZC1sdHItMjAiPgogICAgICA8ZGl2IGNsYXNzPSJjYXJkLWJveCBwZC0yMCBoZWlnaHQtMTAwLXAgbWItMzAiPgogICAgICAgIDxkaXYgY2xhc3M9InJvdyBhbGlnbi1pdGVtcy1jZW50ZXIiPgogICAgICAgICAgPGRpdiBjbGFzcz0iY29sLW1kLTQiPgogICAgICAgICAgICA8aW1nIHNyYz0i';$iapnxu463='IiBhbHQ9IiI+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDxkaXYgY2xhc3M9ImNvbC1tZC04Ij4KICAgICAgICAgICAgPGg0IGNsYXNzPSJmb250LTIwIHdlaWdodC01MDAgbWItMTAgdGV4dC1jYXBpdGFsaXplIj4KICAgICAgICAgICAgICBXZWxjb21lIFRvIDogPGRpdiBjbGFzcz0id2VpZ2h0LTYwMCBmb250LTMwIHRleHQtYmx1ZSI+';$bfixmq464='IHN0b2NrPC9kaXY+CiAgICAgICAgICAgIDwvaDQ+CiAgICAgICAgICAgIDx0YWJsZSBjbGFzcz0idGFibGUgYm9yZGVyLWJvdHRvbSI+CiAgICAgICAgICAgICAgPHRyIGNsYXNzPSJiZy1zZWNvbmRhcnkgdGV4dC13aGl0ZSI+CiAgICAgICAgICAgICAgICA8dGg+U3RvY2sgUmVnLiBObzwvdGg+CiAgICAgICAgICAgICAgICA8dGQ+OiA=';$bfjuks465='PC90ZD4KICAgICAgICAgICAgICA8L3RyPgogICAgICAgICAgICAgIDx0cj4KICAgICAgICAgICAgICAgIDx0aD5UZWxsPC90aD4KICAgICAgICAgICAgICAgIDx0ZD46IA==';$gycava466='PC90ZD4KICAgICAgICAgICAgICA8L3RyPgogICAgICAgICAgICAgIDx0cj4KICAgICAgICAgICAgICAgIDx0aD5FbWFpbDwvdGg+CiAgICAgICAgICAgICAgICA8dGQ+OiA=';$jftwlp467='PC90ZD4KICAgICAgICAgICAgICA8L3RyPiAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgPHRyPgogICAgICAgICAgICAgICAgPHRoPkxvY2F0aW9uPC90aD4KICAgICAgICAgICAgICAgIDx0ZD46IA==';$pcehin468='PC90ZD4KICAgICAgICAgICAgICA8L3RyPgogICAgICAgICAgICA8L3RhYmxlPgogICAgICAgICAgPC9kaXY+CiAgICAgICAgPC9kaXY+CiAgICAgIDwvZGl2Pgo=';$fkuxrj469='CiAgICAgICAgPGRpdiBjbGFzcz0icGFnZS1oZWFkZXIiPgogICAgICAgICAgPGRpdiBjbGFzcz0icm93Ij4KICAgICAgICAgICAgPGRpdiBjbGFzcz0iY29sLW1kLTEyIGNvbC1zbS0xMiB0ZXh0LXJlZCIgYWxpZ249ImNlbnRlciI+CiAgICAgICAgICAgICAgPGRpdiBjbGFzcz0idGl0bGUiPgogICAgICAgICAgICAgICAgPGg0IHN0eWxlPSJjb2xvcjogcmVkICFpbXBvcnRhbnQ7Ij5UaGlzIHN0b2NrIGRvZXMgbm90IGV4aXN0IG9uIG91ciBzeXN0ZW08L2g0PgogICAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDwvZGl2PgogICAgICAgIDwvZGl2Pgo=';$mswjos470='CjxkaXYgaWQ9ImFwcF9kYXRhIj4KICAgICAgPGRpdiBjbGFzcz0icm93Ij4KICAgICAgICAgIDxkaXYgY2xhc3M9ImNvbC1zbS0xMiI+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9ImNhcmQiIHN0eWxlPSJoZWlnaHQ6IDEwMCU7Ij4KICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSJjYXJkLWhlYWRlciI+PGg1PlByb2R1Y3RzIGluIFRoaXMgc3RvY2s8L2g1PgogICAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICAgIDxkaXYgY2xhc3M9ImNhcmQtYm9keSB0YWJsZS1yZXNwb25zaXZlIHAtMiI+CiAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzcz0iZGF0YS10YWJsZSB0YWJsZSB0YWJsZS1ib3JkZXJlZCB0YWJsZS1ob3ZlciB0YWJsZS1zdHJpcGVkIHRleHQtbm93cmFwIiBpZD0iIj4KICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzPSJib3JkZXItdG9wIj4KICAgICAgICAgICAgICAgICAgICA8dHI+CiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9InRhYmxlLXBsdXMgZGF0YXRhYmxlLW5vc29ydCI+UmVnLiBubzwvdGg+CiAgICAgICAgICAgICAgICAgICAgICA8dGg+UHJvZHVjdDwvdGg+CiAgICAgICAgICAgICAgICAgICAgICA8dGg+RGVzY3JpcHRpb248L3RoPiAKICAgICAgICAgICAgICAgICAgICA8L3RyPgogICAgICAgICAgICAgICAgICA8L3RoZWFkPgogICAgICAgICAgICAgICAgICA8dGJvZHk+CiAgICAgICAgICAgICAgICAgICAg';$nxfehn471='CiAgICAgICAgICAgICAgICAgICAgPHRyPgogICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzPSJ0YWJsZS1wbHVzIj4KICAgICAgICAgICAgICAgICAgICAgICAg';$kwvvht472='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPgogICAgICAgICAgICAgICAgICAgICAgPHRkPgogICAgICAgICAgICAgICAgICAgICAgICA=';$rxldyn473='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPgogICAgICAgICAgICAgICAgICAgICAgPHRkPgogICAgICAgICAgICAgICAgICAgICAgICA=';$xabpov474='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPiAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgIDwvdHI+CiAgICAgICAgICAgICAgICAgIA==';$maydkd475='CiAgICAgICAgICAgICAgICAgIDwvdGJvZHk+CiAgICAgICAgICAgICAgICA8L3RhYmxlPgogICAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDwvZGl2PgogICAgICAgICAgPCEtLSAvLmNvbCAtLT4KICAgICAgPC9kaXY+CjwvZGl2Pg=='; $group = dXfa0gHt3::groups(trim(MVoa8gCb_::get('stock')),['data']); $stock_status = array(); if (is_array($group) && isset($group['g_id'])) { $stock_status = dXfa0gHt3::in_stock('',['external']); print(base64_decode($ncicdy462)); echo Xhba9gFiO::menu('icon/on.png'); print(base64_decode($iapnxu463)); echo $group['g_name'] ;print(base64_decode($bfixmq464)); echo $group['g_id']; print(base64_decode($bfjuks465)); echo $group['tell']; print(base64_decode($gycava466)); echo $group['email']; print(base64_decode($jftwlp467)); echo $group['g_location']; print(base64_decode($pcehin468)); }else{ ;print(base64_decode($fkuxrj469)); } ;print(base64_decode($mswjos470)); foreach ($stock_status AS $stock) { $pJK4bgj3P = new CSRF_Protect(); $NcA18fg9Z = $pJK4bgj3P->DbF83gRna(); $product = dXfa0gHt3::products($stock['p_id'],['data']); print(base64_decode($nxfehn471)); echo $stock["p_id"]; print(base64_decode($kwvvht472)); echo $product['p_name']; print(base64_decode($rxldyn473)); echo $product['p_desc']; print(base64_decode($xabpov474)); } ;print(base64_decode($maydkd475)); ?>
