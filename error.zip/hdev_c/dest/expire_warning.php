<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661815)/* Founder*/;$tjnkdb328='CjxkaXYgaWQ9ImFwcF9kYXRhIj4KICAgICAgPGRpdiBjbGFzcz0icm93Ij4KICAgICAgICAgIDxkaXYgY2xhc3M9ImNvbC1zbS0xMiI+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9ImNhcmQiIHN0eWxlPSJoZWlnaHQ6IDEwMCU7Ij4KICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSJjYXJkLWhlYWRlciI+PGg1PlByb2R1Y3RzIEdvaW5nIHRvIGV4cGlyZSBpbiAzIERheXM8L2g1PgogICAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICAgIDxkaXYgY2xhc3M9ImNhcmQtYm9keSB0YWJsZS1yZXNwb25zaXZlIHAtMiI+CiAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzcz0iZGF0YS10YWJsZSB0YWJsZSB0YWJsZS1ib3JkZXJlZCB0YWJsZS1ob3ZlciB0YWJsZS1zdHJpcGVkIHRleHQtbm93cmFwIiBpZD0iIj4KICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzPSJib3JkZXItdG9wIj4KICAgICAgICAgICAgICAgICAgICA8dHI+CiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9InRhYmxlLXBsdXMgZGF0YXRhYmxlLW5vc29ydCI+U3RvY2sgaW4gSUQ8L3RoPgogICAgICAgICAgICAgICAgICAgICAgPHRoPlByb2R1Y3Q8L3RoPgogICAgICAgICAgICAgICAgICAgICAgPHRoPlJlbWFpbmluZyBRdWFudGl0eTwvdGg+CiAgICAgICAgICAgICAgICAgICAgICA8dGg+TWZnIGRhdGU8L3RoPgogICAgICAgICAgICAgICAgICAgICAgPHRoPkV4cCBkYXRlPC90aD4KICAgICAgICAgICAgICAgICAgICAgIDx0aD5TdG9jayByZWcgZGF0ZTwvdGg+CiAgICAgICAgICAgICAgICAgICAgPC90cj4KICAgICAgICAgICAgICAgICAgPC90aGVhZD4KICAgICAgICAgICAgICAgICAgPHRib2R5PgogICAgICAgICAgICAgICAgICAgIA==';$stggdy329='CiAgICAgICAgICAgICAgICAgICAgPHRyPgogICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzPSJ0YWJsZS1wbHVzIj4KICAgICAgICAgICAgICAgICAgICAgICAg';$usyqyl330='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPgogICAgICAgICAgICAgICAgICAgICAgPHRkPgogICAgICAgICAgICAgICAgICAgICAgICA=';$kwvhuy331='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPgogICAgICAgICAgICAgICAgICAgICAgPHRkPgogICAgICAgICAgICAgICAgICAgICAgICA=';$niiuwi332='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPiAKICAgICAgICAgICAgICAgICAgICAgIDx0ZD4KICAgICAgICAgICAgICAgICAgICAgICAg';$gdhapf333='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPgogICAgICAgICAgICAgICAgICAgICAgPHRkPgogICAgICAgICAgICAgICAgICAgICAgICA=';$ifcish334='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPgogICAgICAgICAgICAgICAgICAgICAgPHRkPgogICAgICAgICAgICAgICAgICAgICAgICA=';$ludgnh335='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgIDwvdHI+CiAgICAgICAgICAgICAgICAgIA==';$rhruiy336='CiAgICAgICAgICAgICAgICAgIDwvdGJvZHk+CiAgICAgICAgICAgICAgICA8L3RhYmxlPgogICAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDwvZGl2PgogICAgICAgICAgPCEtLSAvLmNvbCAtLT4KICAgICAgPC9kaXY+CjwvZGl2Pg==';  
 
;print(base64_decode($tjnkdb328)); $COV38gesi = dXfa0gHt3::HHm1afggr('',['warn_exp']);  
 foreach ($COV38gesi AS $stock) { $pJK4bgj3P = new CSRF_Protect(); $NcA18fg9Z = $pJK4bgj3P->DbF83gRna();  
print(base64_decode($stggdy329)); echo $stock["sin_id"]; print(base64_decode($usyqyl330)); echo $stock['p_name']; print(base64_decode($kwvhuy331)); echo $stock['qty_balance'].' '.$stock['p_unit']; print(base64_decode($niiuwi332)); echo $stock['product_mfg_date']; print(base64_decode($gdhapf333)); echo $stock['product_exp_date']; print(base64_decode($ifcish334)); echo $stock['sin_reg_date']; print(base64_decode($ludgnh335)); } ;print(base64_decode($rhruiy336)); ?>
