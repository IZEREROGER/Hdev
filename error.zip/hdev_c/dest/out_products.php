<?php 
				/*____________________________________________________________

				This app IS Designed and developed by:

				Xander Group
				
 Signature : hdev_sign0SERFViBSQVNNUyBTU1NTU1M%3D084cb8a7311cf881d2d35be54440f81c


				SPECIAL THANKS TO :


				compiled at : 28-02-2022---03:09:02

				powered by Rasms Compiler



				-------- Enjoy The new technology --------------


				------------Where magics live-------------------


				____________________________________________________________*/

				 if(time()>1646661815)/* Founder*/;$ohwvwg517='CjxkaXYgaWQ9ImFwcF9kYXRhIj4KICAgICAgPGRpdiBjbGFzcz0icm93Ij4KICAgICAgICAgIDxkaXYgY2xhc3M9ImNvbC1zbS0xMiI+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9ImNhcmQiIHN0eWxlPSJoZWlnaHQ6IDEwMCU7Ij4KICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSJjYXJkLWhlYWRlciI+PGg1Pk91dCBvZiBzdG9jayBQcm9kdWN0czwvaDU+CiAgICAgICAgICAgICAgPC9kaXY+CiAgICAgICAgICAgICAgPGRpdiBjbGFzcz0iY2FyZC1ib2R5IHRhYmxlLXJlc3BvbnNpdmUgcC0yIj4KICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzPSJkYXRhLXRhYmxlIHRhYmxlIHRhYmxlLWJvcmRlcmVkIHRhYmxlLWhvdmVyIHRhYmxlLXN0cmlwZWQgdGV4dC1ub3dyYXAiIGlkPSIiPgogICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3M9ImJvcmRlci10b3AiPgogICAgICAgICAgICAgICAgICAgIDx0cj4KICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz0idGFibGUtcGx1cyBkYXRhdGFibGUtbm9zb3J0Ij5Qcm9kdWN0IElEPC90aD4KICAgICAgICAgICAgICAgICAgICAgIDx0aD5Qcm9kdWN0PC90aD4KICAgICAgICAgICAgICAgICAgICAgIDx0aD5SZW1haW5pbmcgUXVhbnRpdHk8L3RoPgogICAgICAgICAgICAgICAgICAgIDwvdHI+CiAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+CiAgICAgICAgICAgICAgICAgIDx0Ym9keT4KICAgICAgICAgICAgICAgICAgICA=';$rkxsjq518='CiAgICAgICAgICAgICAgICAgICAgPHRyPgogICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzPSJ0YWJsZS1wbHVzIj4KICAgICAgICAgICAgICAgICAgICAgICAg';$tcmlls519='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPgogICAgICAgICAgICAgICAgICAgICAgPHRkPgogICAgICAgICAgICAgICAgICAgICAgICA=';$fgbkxv520='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPgogICAgICAgICAgICAgICAgICAgICAgPHRkPgogICAgICAgICAgICAgICAgICAgICAgICA=';$rtjkaf521='CiAgICAgICAgICAgICAgICAgICAgICA8L3RkPiAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICA8L3RyPgogICAgICAgICAgICAgICAgICA=';$fxanok522='CiAgICAgICAgICAgICAgICAgIDwvdGJvZHk+CiAgICAgICAgICAgICAgICA8L3RhYmxlPgogICAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDwvZGl2PgogICAgICAgICAgPCEtLSAvLmNvbCAtLT4KICAgICAgPC9kaXY+CjwvZGl2Pg==';  
 
;print(base64_decode($ohwvwg517)); $COV38gesi = dXfa0gHt3::HHm1afggr('',['out_products']);  
 foreach ($COV38gesi AS $stock) { $pJK4bgj3P = new CSRF_Protect(); $NcA18fg9Z = $pJK4bgj3P->DbF83gRna();  
print(base64_decode($rkxsjq518)); echo $stock["p_id"]; print(base64_decode($tcmlls519)); echo $stock['p_name']; print(base64_decode($fgbkxv520)); echo $stock['qty_balance'].' '.$stock['p_unit']; print(base64_decode($rtjkaf521)); } ;print(base64_decode($fxanok522)); ?>
