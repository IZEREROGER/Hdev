var CACHE_NAME = 'xnder-st';
var urlsToCache = [
  'vendors/styles/core.css',
  'vendors/styles/icon-font.min.css',
  'src/plugins/jvectormap/jquery-jvectormap-2.0.3.css',
  'vendors/styles/style.css',
  'vendors/scripts/core.js',
  'vendors/scripts/script.min.js',
  'vendors/scripts/process.js',
  'vendors/scripts/layout-settings.js',
  'src/plugins/datatables/js/jquery.dataTables.min.js',
  'src/plugins/datatables/js/dataTables.bootstrap4.min.js',
  'src/plugins/datatables/js/dataTables.responsive.min.js',
  'src/plugins/datatables/js/responsive.bootstrap4.min.js',
  'src/plugins/datatables/js/dataTables.buttons.min.js',
  'src/plugins/datatables/js/buttons.bootstrap4.min.js',
  'src/plugins/datatables/js/buttons.print.min.js',
  'src/plugins/datatables/js/buttons.html5.min.js',
  'src/plugins/datatables/js/buttons.flash.min.js',
  'src/plugins/datatables/js/pdfmake.min.js',
  'src/plugins/datatables/js/vfs_fonts.js',
];
//caches.delete(/*name*/);
self.addEventListener('install', function(event) {
  // Perform install steps
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(function(cache) {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

self.addEventListener('fetch', function(event) {
  event.respondWith(
    caches.match(event.request)
      .then(function(response) {
        // Cache hit - return response
        if (response) {
          return response;
        }

        return fetch(event.request).then(
          function(response) {
            // Check if we received a valid response
            if(!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // IMPORTANT: Clone the response. A response is a stream
            // and because we want the browser to consume the response
            // as well as the cache consuming the response, we need
            // to clone it so we have two streams.

            
            /*var responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then(function(cache) {
                cache.put(event.request, responseToCache);
              });*/

            return response;
          }
        );
      })
    );
});